import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import ProtectedRoute from "./components/routes/ProtectedRoute";
import RoleBasedRoute from "./components/routes/RoleBasedRoute";

import AdminAppRoutes from "./components/routes/AdminAppRoutes";
import DeveloperAppRoutes from "./components/routes/DeveloperAppRoutes";
import UserAppRoutes from "./components/routes/UserAppRoutes";

import LoginPage from "./components/pages/auth/LoginPage";
import SignupPage from "./components/pages/auth/SignupPage";

import Dash from "./components/pages/dashboard/Dash";

import NotFound from "./components/common/errors/404";
import NotAuthorized from "./components/common/errors/401";
import Profile from "./components/pages/profile/Profile";
import CreateTicket from "./components/pages/ticket/CreateTicket";
import ViewTicket from "./components/pages/ticket/ViewTicket";
import { UserDataProvider } from "./components/context/UserDataProvider";
import { DevDataProvider } from "./components/context/DevDataProvider";
import Home from "./components/pages/home/Index";

const App = () => {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />

        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dash />
            </ProtectedRoute>
          }
        >
          {/* Admin Routes */}
          <Route
            path="admin/*"
            element={
              <RoleBasedRoute allowedRoles={["Admin"]}>
                <AdminAppRoutes />
              </RoleBasedRoute>
            }
          />

          {/* Developer Routes */}
          <Route
            path="developer/*"
            element={
              <RoleBasedRoute allowedRoles={["Developer", "Admin"]}>
                <DevDataProvider>
                  <DeveloperAppRoutes />
                </DevDataProvider>
              </RoleBasedRoute>
            }
          />

          {/* User Routes */}
          <Route
            path="user/*"
            element={
              <RoleBasedRoute allowedRoles={["User"]}>
                <UserAppRoutes />
              </RoleBasedRoute>
            }
          />

          <Route path="profile" element={<Profile />} />
          <Route path="create-ticket" element={<CreateTicket />} />
          <Route
            path="ticket/:ticketId"
            element={
              <UserDataProvider>
                <ViewTicket />
              </UserDataProvider>
            }
          />
        </Route>

        <Route path="/" element={<Home />} />
        {/* Error Routes */}
        <Route path="/not-authorized" element={<NotAuthorized />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
};

export default App;

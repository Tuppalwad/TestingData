import React from "react";
import ImportRoutes from "./ImportRoutes";

// Context API's
import { ToastContainer } from "react-toastify";
import { CommonDataProvider } from "./components/context/CommonDataProvider";
import { AuthProvider } from "./components/context/AuthProvider";

// CSS
import "react-toastify/dist/ReactToastify.css";
import { GlobalVariablesProvider } from "./components/context/GlobalVariablesProvider";

function App() {
  return (
    <div className="App">
      <GlobalVariablesProvider>
        <AuthProvider>
          <ToastContainer />
          <CommonDataProvider>
            <ImportRoutes />
          </CommonDataProvider>
        </AuthProvider>
      </GlobalVariablesProvider>
    </div>
  );
}

export default App;

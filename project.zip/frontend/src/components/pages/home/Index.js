import React, { useState, useEffect } from "react";
import ReactMarkdown from "react-markdown";

import teamData from "./team.json";
import "./graph.css";

const TeamGraph = ({ node }) => {
  if (!node) return null;

  return (
    <div className="tree-node">
      <div className="node-content text-wrap">
        <a
          href={`mailto:${node.email}`}
          style={{ textDecoration: "none", color: "#000", fontSize: "0.8rem" }}
        >
          <strong>{node.name}</strong>
        </a>
        <br />
        <span>{node.role || "Role not assigned"}</span>
        <br />
        <em>{node.location}</em>
      </div>
      {node.team && node.team.length > 0 && (
        <div className="node-children">
          {node.team.map((child, index) => (
            <TeamGraph key={index} node={child} />
          ))}
        </div>
      )}
    </div>
  );
};

export default function Home() {
  const [markdownContent, setMarkdownContent] = useState("");

  useEffect(() => {
    const fetchMarkdown = async () => {
      const response = await fetch("/teamInfo.md");
      const text = await response.text();
      setMarkdownContent(text);
    };
    fetchMarkdown();
  }, []);
  console.log(markdownContent);

  return (
    <div className="container p-3">
      <div className="team-info">
        <ReactMarkdown children={markdownContent} />
      </div>
      <h3>Team Structure</h3>
      <div className="tree-container">
        <TeamGraph node={teamData} />
      </div>
    </div>
  );
}

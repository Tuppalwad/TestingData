import React, { useEffect, useState } from "react";
import { useCommonData } from "../../context/CommonDataProvider";

export default function Comments({ data }) {
  const [newComment, setNewComment] = useState("");
  const {
    comments = [],
    getCommentsForTicket,
    createComment,
  } = useCommonData();

  const { socket } = useCommonData();

  useEffect(() => {
    if (!socket || !data.ticketId) return;

    const handleNewReply = () => getCommentsForTicket(data.ticketId);
    const handleNewComment = () => getCommentsForTicket(data.ticketId);

    socket.on("newReply", handleNewReply);
    socket.on("newComment", handleNewComment);

    return () => {
      socket.off("newReply", handleNewReply);
      socket.off("newComment", handleNewComment);
    };
  }, [data.ticketId, socket]);

  const handleAddComment = () => {
    if (!newComment.trim()) return;

    const newCommentObj = {
      content: newComment,
      ticket_id: data.ticket._id,
      ticketId: data.ticketId,
      created_by: data.user._id,
    };

    createComment(newCommentObj);
    setNewComment("");
  };

  const handleAddReply = (commentId, replyText) => {
    if (!replyText.trim()) return;

    const newReply = {
      content: replyText,
      ticketId: data.ticketId,
      ticket_id: data.ticket._id,
      parentCommentId: commentId,
      created_by: data.user._id,
    };

    createComment(newReply);
  };

  return (
    <div className="container">
      <div className="mt-4">
        {comments.length > 0 ? (
          comments.map((comment) => (
            <Comment
              key={comment._id}
              comment={comment}
              onAddReply={handleAddReply}
            />
          ))
        ) : (
          <p>No comments available</p>
        )}
      </div>

      <div className="mt-4">
        <textarea
          className="form-control"
          rows="3"
          placeholder="Add a comment..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
        ></textarea>
        <button
          className="btn btn-primary mt-2"
          onClick={handleAddComment}
          disabled={!newComment.trim()}
        >
          Add Comment
        </button>
      </div>
    </div>
  );
}

function Comment({ comment, onAddReply }) {
  const [replyText, setReplyText] = useState("");
  const [showReplyForm, setShowReplyForm] = useState(false);

  const handleReply = () => {
    onAddReply(comment._id, replyText);
    setReplyText("");
    setShowReplyForm(false);
  };

  return (
    <div className="card mb-3 p-3">
      <div className="d-flex justify-content-between align-items-center">
        <div>
          <strong>{comment.created_by.name}</strong>{" "}
          <small>{new Date(comment.createdAt).toLocaleString()}</small>
        </div>
        <button
          className="btn btn-link p-0 text-secondary"
          onClick={() => setShowReplyForm(!showReplyForm)}
        >
          <i className="bi bi-reply-all-fill"></i> Reply
        </button>
      </div>
      <p>{comment.content}</p>

      {showReplyForm && (
        <div className="mt-2" style={{ paddingLeft: "30px" }}>
          <textarea
            className="form-control"
            rows="2"
            placeholder="Write a reply..."
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
          ></textarea>
          <button
            className="btn btn-primary mt-2"
            onClick={handleReply}
            disabled={!replyText.trim()}
          >
            Add Reply
          </button>
        </div>
      )}

      {comment.replies.length > 0 && (
        <div className="mt-3" style={{ paddingLeft: "30px" }}>
          {comment.replies.map((reply) => (
            <div key={reply._id} className="d-flex align-items-center mb-2">
              <div
                style={{
                  backgroundColor: "#e9ecef",
                  padding: "10px",
                  borderRadius: "5px",
                }}
              >
                <strong>{reply.created_by.name}</strong>
                <small>{new Date(reply.createdAt).toLocaleString()}</small>
                <p>{reply.content}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

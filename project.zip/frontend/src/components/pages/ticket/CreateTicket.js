import React, { useState } from "react";
import modulesData from "./modules.json";
import { toast } from "react-toastify";
import { useCommonData } from "../../context/CommonDataProvider";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import "./quill.css";
import { useAuth } from "../../context/AuthProvider";

export default function CreateTicket() {
  const { user } = useAuth();
  const today = new Date();
  const tomorrow = new Date();
  tomorrow.setDate(today.getDate() + 1);

  const { CreateTicket } = useCommonData();

  const [ticketData, setTicketData] = useState({
    title: "",
    description: "",
    priority: "Low",
    state: "ACTIVE",
    created_by: user.id,
    module: "",
    submodule: "",
    dueDate: today.toISOString().split("T")[0],
  });

  const [submodules, setSubmodules] = useState([]);
  const [errors, setErrors] = useState({});

  // Handle change for input fields
  const handleChange = (e) => {
    const { name, value } = e.target;
    setTicketData({ ...ticketData, [name]: value });
    if (name === "module") {
      const selectedModule = modulesData.modules.find(
        (module) => module.name === value
      );
      setSubmodules(selectedModule ? selectedModule.submodules : []);
      setTicketData((prev) => ({ ...prev, submodule: "" }));
    }
  };

  // Handle Quill editor change
  const handleEditorChange = (value) => {
    setTicketData({ ...ticketData, description: value });
  };

  // Form validation
  const validateForm = () => {
    const newErrors = {};

    if (!ticketData.title) {
      newErrors.title = "Title is required.";
    } else if (ticketData.title.length < 5 || ticketData.title.length > 50) {
      newErrors.title = "Title must be between 5 and 50 characters.";
    }

    if (!ticketData.description) {
      newErrors.description = "Description is required.";
    } else if (
      ticketData.description.length < 10 ||
      ticketData.description.length > 500
    ) {
      newErrors.description =
        "Description must be between 10 and 500 characters.";
    }

    if (!ticketData.module) {
      newErrors.module = "Module is required.";
    }

    if (ticketData.module && submodules.length > 0 && !ticketData.submodule) {
      newErrors.submodule = "Submodule is required.";
    }

    if (!ticketData.dueDate) {
      newErrors.dueDate = "Due date is required.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const resetForm = {
    title: "",
    description: "",
    priority: "Low",
    state: "Open",
    user: user.userId,
    module: "",
    submodule: "",
    dueDate: today.toISOString().split("T")[0],
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validateForm()) {
      const formattedData = {
        ...ticketData,
        dueDate: new Date(ticketData.dueDate).toISOString(),
      };

      try {
        await CreateTicket(formattedData);
        console.log(formattedData);
        setTicketData(resetForm);
      } catch (error) {
        console.error("Error creating ticket:", error);
        toast.error(
          "There was an issue creating the ticket. Please try again."
        );
      }
    }
  };

  const minDate = today.toISOString().split("T")[0];
  const maxDate = new Date(today);
  maxDate.setDate(today.getDate() + 7);
  const maxDateStr = maxDate.toISOString().split("T")[0];

  return (
    <div className="pagetitle">
      <h1>Create Ticket</h1>
      <nav>
        <ol className="breadcrumb">
          <li className="breadcrumb-item">
            <a href="/dashboard">Dashboard</a>
          </li>
          <li className="breadcrumb-item active">Create Ticket</li>
        </ol>
      </nav>
      <section className="section">
        <div className="row">
          <div className="container-fluid">
            <div className="card py-3">
              <div className="card-body">
                <form className="g-3" onSubmit={handleSubmit}>
                  <div className="row">
                    <div className="col-md-8">
                      <div className="mb-3">
                        <label htmlFor="title" className="form-label">
                          Title
                        </label>
                        <input
                          type="text"
                          className={`form-control ${
                            errors.title ? "is-invalid" : ""
                          }`}
                          id="title"
                          name="title"
                          value={ticketData.title}
                          onChange={handleChange}
                          required
                          placeholder="Enter ticket title"
                        />
                        {errors.title && (
                          <div className="invalid-feedback">{errors.title}</div>
                        )}
                      </div>

                      <div className="mb-3">
                        <label htmlFor="description" className="form-label">
                          Description
                        </label>
                        <ReactQuill
                          value={ticketData.description}
                          onChange={handleEditorChange}
                          theme="snow"
                          className={`${
                            errors.description ? "is-invalid" : ""
                          }`}
                          placeholder="Enter ticket description"
                          required
                        />
                        {errors.description && (
                          <div className="invalid-feedback">
                            {errors.description}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="col-md-4">
                      <div className="mb-3">
                        <label htmlFor="module" className="form-label">
                          Module
                        </label>
                        <select
                          className={`form-select ${
                            errors.module ? "is-invalid" : ""
                          }`}
                          id="module"
                          name="module"
                          value={ticketData.module}
                          onChange={handleChange}
                          required
                        >
                          <option value="">Select a module</option>
                          {modulesData.modules.map((module) => (
                            <option key={module.name} value={module.name}>
                              {module.name}
                            </option>
                          ))}
                        </select>
                        {errors.module && (
                          <div className="invalid-feedback">
                            {errors.module}
                          </div>
                        )}
                      </div>

                      {submodules.length > 0 && (
                        <div className="mb-3">
                          <label htmlFor="submodule" className="form-label">
                            Submodule
                          </label>
                          <select
                            className={`form-select ${
                              errors.submodule ? "is-invalid" : ""
                            }`}
                            id="submodule"
                            name="submodule"
                            value={ticketData.submodule}
                            onChange={handleChange}
                          >
                            <option value="">
                              {ticketData.module
                                ? `Submodules for ${ticketData.module}`
                                : "Select a submodule"}
                            </option>
                            {submodules.map((submodule) => (
                              <option
                                key={submodule.name}
                                value={submodule.name}
                              >
                                {submodule.name}
                              </option>
                            ))}
                          </select>
                          {errors.submodule && (
                            <div className="invalid-feedback">
                              {errors.submodule}
                            </div>
                          )}
                        </div>
                      )}

                      <div className="mb-3">
                        <label htmlFor="dueDate" className="form-label">
                          Due Date
                        </label>
                        <input
                          type="date"
                          className={`form-control ${
                            errors.dueDate ? "is-invalid" : ""
                          }`}
                          id="dueDate"
                          name="dueDate"
                          value={ticketData.dueDate}
                          onChange={handleChange}
                          min={minDate}
                          max={maxDateStr}
                          required
                        />
                        {errors.dueDate && (
                          <div className="invalid-feedback">
                            {errors.dueDate}
                          </div>
                        )}
                      </div>

                      <div className="mb-3">
                        <label htmlFor="priority" className="form-label">
                          Priority
                        </label>
                        <select
                          className="form-select"
                          id="priority"
                          name="priority"
                          value={ticketData.priority}
                          onChange={handleChange}
                        >
                          <option value="Low">Low</option>
                          <option value="Medium">Medium</option>
                          <option value="High">High</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="col-12"></div>

                  <button type="submit" className="btn btn-primary">
                    Create Ticket
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

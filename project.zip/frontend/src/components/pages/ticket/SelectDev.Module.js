import React, { useEffect, useState } from "react";
import { useCommonData } from "../../context/CommonDataProvider";

export default function SelectDevModule({ value, setUpdatedTicket }) {
  const { getDevsAndAdmins } = useCommonData();
  const [devsAndAdmins, setDevsAndAdmins] = useState([]);

  useEffect(() => {
    const fetchDevsAndAdmins = async () => {
      try {
        const data = await getDevsAndAdmins();
        setDevsAndAdmins(data);
      } catch (error) {
        console.error("Error fetching Devs and Admins:", error);
      }
    };

    fetchDevsAndAdmins();
  }, []);

  const handleSelectChange = (e) => {
    setUpdatedTicket((prev) => ({
      ...prev,
      assignedTo: e.target.value,
    }));
  };

  return (
    <div className="mb-3">
      <select
        className="form-select"
        aria-label="Select a developer"
        required
        value={value}
        onChange={handleSelectChange}
      >
        <option value="" disabled selected>
          Select a developer
        </option>
        {devsAndAdmins.map((user) => (
          <option key={user._id} value={user._id}>
            {user.name}
          </option>
        ))}
      </select>
    </div>
  );
}

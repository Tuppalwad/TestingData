import React from "react";

export default function History({ logs }) {
  return (
    <>
      {logs ? (
        <>
          <div className="card shadow-sm">
            <div className="card-body">
              <h5 className="card-title mb-3">Recent Activity</h5>
              <div
                className="activity"
                style={{ maxHeight: "600px", overflowY: "auto" }}
              >
                {logs && logs.length > 0 ? (
                  [...logs].reverse().map((log) => (
                    <div
                      className="activity-item mb-4 border shadow p-2 rounded"
                      key={log._id}
                      style={{ wordWrap: "break-word" }}
                    >
                      <div className="activity-time text-muted small mb-2">
                        <strong>{log.action_by.name || "Unknown User"}</strong>
                        {" | "}
                        <strong>Date:</strong>{" "}
                        {new Date(log.createdAt).toLocaleDateString()}{" "}
                        <strong>Time:</strong>{" "}
                        {new Date(log.createdAt).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </div>

                      <div className="activity-content">
                        {log.changes && (
                          <div className="changes mb-2">
                            <p>
                              <strong className="small">Changed Fields:</strong>{" "}
                              <span className="text-wrap small">
                                {Object.keys(log?.changes || {}).join(", ")}
                              </span>
                              <br />
                              <strong className="small">
                                Description:
                              </strong>{" "}
                              <span className="text-wrap small">
                                {log?.description || "No description provided"}
                              </span>
                            </p>
                          </div>
                        )}

                        {log.tags.length > 0 && (
                          <div className="tags mt-1">
                            <strong className="small">Tags:</strong>{" "}
                            <span className="badge bg-secondary small">
                              {log.tags.join(", ")}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-muted text-center small">
                    No activity found for this ticket.
                  </div>
                )}
              </div>
            </div>
          </div>
        </>
      ) : (
        <>
          <p>No logs available for given ticket</p>
        </>
      )}
    </>
  );
}

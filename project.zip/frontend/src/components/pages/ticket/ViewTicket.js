import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useCommonData } from "../../context/CommonDataProvider";
import { useAuth } from "../../context/AuthProvider";
import Comments from "./Comments";
import SelectDevModule from "./SelectDev.Module";
import Swal from "sweetalert2";
import History from "./History";

export default function ViewTicket() {
  const { ticketId } = useParams();
  const [editable, setEditable] = useState(false);
  const { getTicketByTicketId, ticket, updateTicket } = useCommonData();
  const { user } = useAuth();
  console.log(ticket);

  const [updatedTicket, setUpdatedTicket] = useState({
    rca: ticket?.rca || null,
    resolutionDescription: ticket?.resolution_description || null,
    state: ticket?.state || "ACTIVE",
    priority: ticket?.priority || "Low",
    module: ticket?.module || null,
    submodule: ticket?.submodule || null,
    assignedTo: ticket?.assigned_to || null,
  });

  useEffect(() => {
    if (ticketId) {
      getTicketByTicketId(ticketId);
    }
    setEditable(user.role.name !== "User");
  }, [ticketId, user]);

  const handleUpdate = async () => {
    const { value: logDescription } = await Swal.fire({
      title: "Enter Comment for your actions",
      input: "text",
      inputPlaceholder: "Describe the reason for your actions",
      showCancelButton: true,
      inputValidator: (value) => {
        if (!value) {
          return "Log description is required!";
        }
      },
    });

    if (logDescription) {
      const changedFields = Object.keys(updatedTicket).reduce((diff, key) => {
        if (updatedTicket[key] !== ticket[key] && updatedTicket[key] !== null) {
          diff[key] = updatedTicket[key];
        }
        return diff;
      }, {});

      if (Object.keys(changedFields).length === 0) {
        return;
      }

      const updatedPayload = {
        ticketId: ticket?.ticketId,
        logDescription,
        ...changedFields,
      };

      try {
        await updateTicket(updatedPayload);
      } catch (err) {
        console.error("Error updating ticket:", err);
      }
    }
  };

  const handleFieldChange = (field, value) => {
    setUpdatedTicket((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  return (
    <>
      <div className="card p-2">
        <div className="card-body mt-3">
          {ticket ? (
            <>
              <h3 className="fw-bold">
                {ticket.ticketId}
                {" : "}
                {ticket.title}
              </h3>
              <div className="border-bottom border-secondary"></div>
              <div className="row mt-3">
                <div className="col-md-8 border-end border-secondary">
                  <p className="mb-5">
                    <strong>Description:</strong>{" "}
                    <span
                      dangerouslySetInnerHTML={{
                        __html: ticket.description,
                      }}
                    ></span>
                  </p>

                  {editable && (
                    <>
                      <div className="mb-3">
                        <label htmlFor="RCA">RCA</label>
                        <textarea
                          id="RCA"
                          className="form-control"
                          rows="3"
                          value={ticket.rca}
                          onChange={(e) =>
                            handleFieldChange("rca", e.target.value)
                          }
                        ></textarea>
                      </div>

                      <div className="mb-3">
                        <label htmlFor="ResolutionDescription">
                          Resolution Description
                        </label>
                        <textarea
                          id="ResolutionDescription"
                          className="form-control"
                          rows="3"
                          value={ticket.resolutionDescription}
                          onChange={(e) =>
                            handleFieldChange(
                              "resolutionDescription",
                              e.target.value
                            )
                          }
                        ></textarea>
                      </div>
                      <div className="row">
                        <div className="col-md-4">
                          <div className="mb-3">
                            <label htmlFor="State">State</label>
                            <select
                              id="State"
                              className="form-select"
                              value={ticket.state}
                              onChange={(e) =>
                                handleFieldChange("state", e.target.value)
                              }
                            >
                              <option value="ACTIVE">ACTIVE</option>
                              <option value="IN PROGRESS">IN PROGRESS</option>
                              <option value="CLOSED">CLOSED</option>
                              <option value="REJECTED">REJECTED</option>
                              <option value="RESOLVED">RESOLVED</option>
                              <option value="REOPENED">REOPENED</option>
                            </select>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="mb-3">
                            <label htmlFor="Priority">Priority</label>
                            <select
                              id="Priority"
                              className="form-select"
                              value={ticket.priority}
                              onChange={(e) =>
                                handleFieldChange("priority", e.target.value)
                              }
                            >
                              <option value="Low">Low</option>
                              <option value="Medium">Medium</option>
                              <option value="High">High</option>
                            </select>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="mb-3">
                            <label htmlFor="Module">Module</label>
                            <input
                              id="Module"
                              type="text"
                              className="form-control"
                              value={ticket.module}
                              onChange={(e) =>
                                handleFieldChange("module", e.target.value)
                              }
                            />
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-md-4">
                          <div className="mb-3">
                            <label htmlFor="Submodule">Submodule</label>
                            <input
                              id="Submodule"
                              type="text"
                              className="form-control"
                              value={ticket.submodule}
                              onChange={(e) =>
                                handleFieldChange("submodule", e.target.value)
                              }
                            />
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="mb-3">
                            <strong>Assigned to:</strong>{" "}
                            {editable ? (
                              <SelectDevModule
                                value={
                                  ticket.assignedTo || ticket?.assigned_to?._id
                                }
                                setUpdatedTicket={setUpdatedTicket}
                              />
                            ) : (
                              "NA"
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="mb-3">
                        <button
                          className="btn btn-sm btn-primary"
                          onClick={handleUpdate}
                        >
                          Update Changes
                        </button>
                      </div>
                    </>
                  )}
                </div>

                <div className="col-md-4">
                  <p>
                    <strong>Due Date:</strong>{" "}
                    {ticket?.due_date
                      ? new Date(ticket.due_date).toLocaleDateString()
                      : "N/A"}
                  </p>
                  <p>
                    <strong>Created By:</strong>{" "}
                    {ticket?.created_by?.name || "Unknown"}
                  </p>
                  <p>
                    <strong>Created At:</strong>{" "}
                    {ticket?.createdAt
                      ? new Date(ticket.createdAt).toLocaleString()
                      : "N/A"}
                  </p>
                </div>
              </div>
            </>
          ) : (
            <p>Loading ticket details...</p>
          )}
        </div>
      </div>
      <div className="row">
        <div className="col-md-6">
          <Comments data={{ ticketId, user, ticket }} />
        </div>
        <div className="col-md-6">
          <History logs={ticket?.logs} />
        </div>
      </div>
    </>
  );
}

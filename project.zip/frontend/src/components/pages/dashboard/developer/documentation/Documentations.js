import React, { useState, useEffect } from "react";
import { useDevData } from "../../../../context/DevDataProvider";

export default function Documentations() {
  const [documentations, setDocumentations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedDoc, setSelectedDoc] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredDocs, setFilteredDocs] = useState([]);

  const { docs, getDocs } = useDevData();

  useEffect(() => {
    setLoading(true);
    try {
      if (docs && docs.length > 0) {
        setDocumentations(docs);
        setFilteredDocs(docs);
      } else {
        setError("No documentation available.");
      }
    } catch (error) {
      setError("Failed to load documentation");
    } finally {
      setLoading(false);
    }
  }, [docs]);

  useEffect(() => {
    getDocs();
  }, []);

  useEffect(() => {
    setFilteredDocs(
      documentations.filter((doc) =>
        doc.title.toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  }, [searchTerm, documentations]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  function viewDocumentation(docId) {
    const selectedDoc = documentations.find((doc) => doc._id === docId);
    setSelectedDoc(selectedDoc);
    const modal = new window.bootstrap.Modal(
      document.getElementById("modalDialogScrollable")
    );
    modal.show();
  }

  return (
    <>
      <div className="mb-3">
        <input
          type="text"
          className="form-control"
          placeholder="Search Documentation by Title"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 mt-2">
        {filteredDocs.length === 0 ? (
          <div>No documentation available</div>
        ) : (
          filteredDocs.map((doc) => (
            <div key={doc._id} className="col">
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">{doc.title}</h5>
                  <p className="card-text">{doc.resolutionSummary}</p>
                  <small>Ticket ID: {doc.ticketId}</small>
                  <div className="mt-2">
                    <button
                      className="btn btn-info btn-sm"
                      onClick={() => viewDocumentation(doc._id)}
                    >
                      View Details
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <div
        className="modal modal-xl fade"
        id="modalDialogScrollable"
        tabIndex="-1"
        aria-labelledby="modalDialogScrollableLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-scrollable">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="modalDialogScrollableLabel">
                {selectedDoc ? (
                  <>
                    <p className="fw-bold">
                      {selectedDoc.docId}
                      {" : "}
                      {selectedDoc.title}
                    </p>
                  </>
                ) : (
                  "Loading..."
                )}
              </h5>
              {/* <button type="button" className="btn btn-warning ms-auto">
                Edit
              </button> */}
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              {selectedDoc ? (
                <div className="row">
                  <div className="col-md-8">
                    <p className="fw-bold">Description: </p>
                    <p
                      dangerouslySetInnerHTML={{
                        __html: selectedDoc.resolution_steps,
                      }}
                    ></p>
                    <p className="fw-bold">Resolution Steps: </p>
                    <p
                      dangerouslySetInnerHTML={{
                        __html: selectedDoc.description,
                      }}
                    ></p>
                  </div>
                  <div className="border-start border-secondary col-md-4">
                    <p className="fw-bold">Ticket ID: </p>
                    <p>{selectedDoc.ticketId || "NA"}</p>
                    <p className="fw-bold">Module: </p>
                    <p>{selectedDoc.module || "NA"}</p>
                    <p className="fw-bold">Submodule: </p>
                    <p>{selectedDoc.submodule || "NA"}</p>
                    <p className="fw-bold">Created By: </p>
                    <p>
                      {selectedDoc.created_by.name || "NA"} (
                      {selectedDoc.created_by.email || "NA"})
                    </p>
                    <p className="fw-bold">Tags: </p>
                    <ul>
                      {selectedDoc.tags.length > 0 ? (
                        selectedDoc.tags.map((tag, index) => (
                          <li key={index}>{tag}</li>
                        ))
                      ) : (
                        <li>NA</li>
                      )}
                    </ul>
                    <p className="fw-bold">References: </p>
                    <ul>
                      {selectedDoc.references.length > 0 ? (
                        selectedDoc.references.map((ref, index) => (
                          <li key={index}>{ref}</li>
                        ))
                      ) : (
                        <li>NA</li>
                      )}
                    </ul>
                  </div>

                  <hr />
                  <p className="text-muted">
                    <span>
                      Created At :{" "}
                      {new Date(selectedDoc.createdAt).toLocaleString() || "NA"}
                    </span>
                  </p>

                  <p className="text-muted">
                    <span>
                      Updated At :{" "}
                      {new Date(selectedDoc.updatedAt).toLocaleString() || "NA"}
                    </span>
                  </p>
                </div>
              ) : (
                <p>Loading documentation details...</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

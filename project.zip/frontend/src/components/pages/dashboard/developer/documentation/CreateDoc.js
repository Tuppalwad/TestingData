import React, { useEffect, useState } from "react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import { useDevData } from "../../../../context/DevDataProvider";
import { toast } from "react-toastify";
import { useParams } from "react-router-dom";

export default function CreateDoc() {
  const { ticket_id } = useParams();

  const [title, setTitle] = useState("");
  const [associated_ticket, setAssociatedTicket] = useState();
  const [ticketId, setTicketId] = useState("");
  const [module, setModule] = useState("");
  const [submodule, setSubmodule] = useState("");
  const [resolutionSummary, setResolutionSummary] = useState("");
  const [detailedSteps, setDetailedSteps] = useState("");
  const [tags, setTags] = useState("");

  const { createDoc } = useDevData();

  useEffect(() => {
    if (ticket_id) {
      setAssociatedTicket(ticket_id);
    }
  }, [ticket_id]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const documentation = {
      title,
      ticketId: ticketId,
      resolution_steps: resolutionSummary,
      associated_ticket,
      description: detailedSteps,
      tags: tags.split(",").map((tag) => tag.trim()) || [],
      module,
      submodule,
    };

    try {
      await createDoc(documentation);

      setTitle("");
      setTicketId("");
      setModule("");
      setSubmodule("");
      setResolutionSummary("");
      setDetailedSteps("");
      setTags("");

      toast.success("Doc created!");
    } catch (error) {
      console.error("Error submitting documentation:", error);
      toast.error("Failed to create doc.");
    }
  };

  return (
    <div className="card p-2">
      <div className="card-body py-2">
        <h2 className="mb-3">
          <span className="border-bottom border-primary text-primary">
            Create Documentation
          </span>
        </h2>

        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="title" className="form-label">
              Documentation Title <span className="text-danger">*</span>
            </label>
            <input
              type="text"
              className="form-control"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>
          <div className="row">
            <div className="col-md-4">
              <div className="mb-3">
                <label htmlFor="ticketId" className="form-label">
                  Ticket ID ("NA" if not)
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="ticketId"
                  value={ticketId}
                  onChange={(e) => setTicketId(e.target.value)}
                  required
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="mb-3">
                <label htmlFor="module" className="form-label">
                  Module ("NA" if not)
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="module"
                  value={module}
                  onChange={(e) => setModule(e.target.value)}
                  required
                />
              </div>
            </div>
            <div className="col-md-4">
              <div className="mb-3">
                <label htmlFor="submodule" className="form-label">
                  Submodule ("NA" if not)
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="submodule"
                  value={submodule}
                  onChange={(e) => setSubmodule(e.target.value)}
                />
              </div>
            </div>
          </div>

          <div className="mb-3">
            <label htmlFor="resolutionSummary" className="form-label">
              Resolution Summary <span className="text-danger">*</span>
            </label>
            <ReactQuill
              id="resolutionSummary"
              value={resolutionSummary}
              onChange={setResolutionSummary}
              placeholder="Write a brief resolution summary"
              required
            />
          </div>

          <div className="mb-3">
            <label htmlFor="detailedSteps" className="form-label">
              Detailed Steps <span className="text-danger">*</span>
            </label>
            <ReactQuill
              id="detailedSteps"
              value={detailedSteps}
              onChange={setDetailedSteps}
              placeholder="Write detailed steps to resolve the issue"
              required
            />
          </div>

          <div className="mb-3">
            <label htmlFor="tags" className="form-label">
              Tags (comma separated) <span className="text-danger">*</span>
            </label>
            <input
              type="text"
              className="form-control"
              id="tags"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="e.g., Database, Network"
            />
          </div>

          <button type="submit" className="btn btn-primary">
            Save Documentation
          </button>
        </form>
      </div>
    </div>
  );
}

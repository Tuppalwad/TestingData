import React, { useState, useEffect } from "react";
import ReactPaginate from "react-paginate";
import { Link } from "react-router-dom";
import { useDevData } from "../../../../context/DevDataProvider";

export default function AssignedTickets() {
  const [ticketsPerPage, setTicketsPerPage] = useState(5);
  const [pageCount, setPageCount] = useState(0);
  const [paginatedTickets, setPaginatedTickets] = useState([]);
  const [currentPage, setCurrentPage] = useState(0);

  const { getAssignedTickets, assignedTickets } = useDevData();

  useEffect(() => {
    getAssignedTickets();
  }, []);

  useEffect(() => {
    if (Array.isArray(assignedTickets)) {
      const offset = currentPage * ticketsPerPage;
      const paginatedData = assignedTickets.slice(
        offset,
        offset + ticketsPerPage
      );
      setPaginatedTickets(paginatedData);
      setPageCount(Math.ceil(assignedTickets.length / ticketsPerPage));
    }
  }, [assignedTickets, currentPage, ticketsPerPage]);

  const handlePageChange = (selectedPage) => {
    setCurrentPage(selectedPage.selected);
  };

  // Function to get ticket state color
  const getStateColor = (state) => {
    switch (state) {
      case "In Progress":
        return "badge-warning";
      case "Resolved":
        return "badge-success";
      case "Pending":
        return "badge-secondary";
      default:
        return "badge-info";
    }
  };

  // Function to get priority color
  const getPriorityColor = (priority) => {
    switch (priority) {
      case "High":
        return "badge-danger";
      case "Medium":
        return "badge-warning";
      case "Low":
        return "badge-success";
      default:
        return "badge-secondary";
    }
  };

  return (
    <div className="container mt-4">
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Assigned Tickets</h5>
          <div className="d-flex justify-content-between align-items-center mb-3">
            <label>
              Show{" "}
              <select
                className="form-select form-select-sm d-inline-block w-auto"
                value={ticketsPerPage}
                onChange={(e) => setTicketsPerPage(Number(e.target.value))}
              >
                <option value="5">5</option>
                <option value="10">10</option>
                <option value="20">20</option>
              </select>{" "}
              entries
            </label>
          </div>
          <div className="list-group">
            {paginatedTickets && paginatedTickets.length > 0 ? (
              paginatedTickets.map((ticket) => (
                <Link
                  key={ticket._id}
                  to={`/dashboard/ticket/${ticket.ticketId}`}
                  className="list-group-item list-group-item-action"
                  aria-current="true"
                >
                  <div className="d-flex w-100 justify-content-between">
                    <h5 className="mb-0 fw-bold text-truncate">
                      {ticket.title}
                    </h5>
                    <small className="fw-bold">
                      Due:{" "}
                      {new Date(ticket.due_date).toLocaleDateString("en-US")}
                    </small>
                  </div>
                  <p className="text-muted mb-0 truncate-multiline">
                    <span
                      dangerouslySetInnerHTML={{ __html: ticket.description }}
                    ></span>
                  </p>

                  <small>
                    <span
                      className={`badge ${getStateColor(ticket.state)} me-2`}
                    >
                      Ticket: {ticket.state}
                    </span>
                    <span
                      className={`badge ${getPriorityColor(
                        ticket.priority
                      )} me-2`}
                    >
                      Priority: {ticket.priority}
                    </span>
                    Module: {ticket.module} | Submodule: {ticket.submodule}
                  </small>
                </Link>
              ))
            ) : (
              <p className="text-muted">No assigned tickets found.</p>
            )}
          </div>
          <ReactPaginate
            previousLabel={"Previous"}
            nextLabel={"Next"}
            breakLabel={"..."}
            pageCount={pageCount}
            marginPagesDisplayed={2}
            pageRangeDisplayed={3}
            onPageChange={handlePageChange}
            containerClassName={"pagination justify-content-center mt-4"}
            pageClassName={"page-item"}
            pageLinkClassName={"page-link"}
            previousClassName={"page-item"}
            previousLinkClassName={"page-link"}
            nextClassName={"page-item"}
            nextLinkClassName={"page-link"}
            breakClassName={"page-item"}
            breakLinkClassName={"page-link"}
            activeClassName={"active"}
          />
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useDevData } from "../../../../context/DevDataProvider";

export default function Board() {
  const { getBoardData, board } = useDevData();

  useEffect(() => {
    getBoardData();
  }, []);

  const filterTicketsByGroupedStatus = (statuses) => {
    if (!Array.isArray(board)) {
      console.error("Board data is not an array or is undefined.");
      return [];
    }
    return board.filter((ticket) => statuses.includes(ticket.state));
  };

  const toDoTickets = filterTicketsByGroupedStatus(["ACTIVE", "REOPENED"]);
  const inProgressTickets = filterTicketsByGroupedStatus(["IN PROGRESS"]);
  const finalizedTickets = filterTicketsByGroupedStatus([
    "RESOLVED",
    "CLOSED",
    "REJECTED",
  ]);

  const getPriorityColor = (priority) => {
    switch (priority) {
      case "High":
        return "badge-danger";
      case "Medium":
        return "badge-warning";
      case "Low":
        return "badge-success";
      default:
        return "badge-secondary";
    }
  };

  const renderTickets = (tickets) => {
    return tickets.length > 0 ? (
      tickets.map((ticket) => (
        <div
          key={ticket._id}
          className="card mb-3 shadow-sm"
          style={{ borderRadius: "10px" }}
        >
          <Link
            to={`/dashboard/ticket/${ticket.ticketId}`}
            className="text-decoration-none"
            aria-current="true"
          >
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-center">
                <h5 className="mb-0 fw-bold text-truncate mt-2 mb-1">
                  {ticket.title}
                </h5>
                <small className="text-muted">
                  Due: {new Date(ticket.due_date).toLocaleDateString("en-US")}
                </small>
              </div>
              {/* <div
                className="one-line-truncate text-muted mt-2 mb-2"
                dangerouslySetInnerHTML={{ __html: ticket.description }}
              ></div> */}

              <div className="d-flex align-items-center">
                <span
                  className={`badge ${getPriorityColor(ticket.priority)} me-2`}
                >
                  {ticket.priority}
                </span>
                <small className="text-muted">
                  Assigned to:{" "}
                  {ticket.assigned_to?.name ||
                    ticket.assigned_to?.email ||
                    "Unassigned"}
                </small>
              </div>
            </div>
          </Link>
        </div>
      ))
    ) : (
      <div className="text-center py-3">
        <p className="text-muted">No tickets available.</p>
      </div>
    );
  };

  return (
    <div className="container mt-2">
      <div
        className="card"
        style={{
          backgroundColor: "#F8F8F8",
        }}
      >
        <div className="card-body">
          <h5 className="card-title">Ticket Overview</h5>

          <ul
            className="nav nav-tabs nav-tabs-bordered d-flex"
            id="ticketTab"
            role="tablist"
          >
            <li className="nav-item flex-fill" role="presentation">
              <button
                className="nav-link active"
                id="todo-tab"
                data-bs-toggle="tab"
                data-bs-target="#todo"
                type="button"
                role="tab"
                aria-controls="todo"
                aria-selected="true"
              >
                To Do{" "}
                <span className="badge bg-danger badge-number">
                  {toDoTickets?.length}
                </span>
              </button>
            </li>
            <li className="nav-item flex-fill" role="presentation">
              <button
                className="nav-link"
                id="inprogress-tab"
                data-bs-toggle="tab"
                data-bs-target="#inprogress"
                type="button"
                role="tab"
                aria-controls="inprogress"
                aria-selected="false"
              >
                In Progress{" "}
                <span className="badge bg-primary badge-number">
                  {inProgressTickets?.length}
                </span>
              </button>
            </li>
            <li className="nav-item flex-fill" role="presentation">
              <button
                className="nav-link"
                id="finalized-tab"
                data-bs-toggle="tab"
                data-bs-target="#finalized"
                type="button"
                role="tab"
                aria-controls="finalized"
                aria-selected="false"
              >
                Finalized{" "}
                <span className="badge bg-success badge-number">
                  {finalizedTickets?.length}
                </span>
              </button>
            </li>
          </ul>

          <div className="tab-content pt-3" id="ticketTabContent">
            <div
              className="tab-pane fade show active"
              id="todo"
              role="tabpanel"
              aria-labelledby="todo-tab"
            >
              {renderTickets(toDoTickets)}
            </div>
            <div
              className="tab-pane fade"
              id="inprogress"
              role="tabpanel"
              aria-labelledby="inprogress-tab"
            >
              {renderTickets(inProgressTickets)}
            </div>
            <div
              className="tab-pane fade"
              id="finalized"
              role="tabpanel"
              aria-labelledby="finalized-tab"
            >
              {renderTickets(finalizedTickets)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

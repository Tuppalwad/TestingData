import React, { useEffect } from "react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import { useDevData } from "../../../context/DevDataProvider";

export default function DeveloperDashboard() {
  const { getDeveloperAnalytics, devAnalytics } = useDevData();

  useEffect(() => {
    async function fetchAnalytics() {
      await getDeveloperAnalytics();
    }
    fetchAnalytics();
  }, []);

  // Pie chart data for ticket status
  const statusData = [
    { name: "Assigned", value: devAnalytics?.assignedTicketsCount },
    { name: "Open", value: devAnalytics?.openTicketsCount },
    { name: "Overdue", value: devAnalytics?.overdueTicketsCount },
  ];

  // Colors for the pie chart
  const COLORS = ["#4CAF50", "#FF9800", "#F44336"];

  return (
    <div className="container mt-4">
      <h3>Developer Dashboard</h3>

      {/* Analytics Overview */}
      <div className="row mb-4">
        <div className="col-6">
          <div className="row">
            <div className="col-6">
              <div className="card text-center">
                <div className="card-body">
                  <h5 className="card-title">Assigned Tickets</h5>
                  <p className="card-text display-4">
                    {devAnalytics?.assignedTicketsCount}
                  </p>
                </div>
              </div>
            </div>
            <div className="col-6">
              <div className="card text-center">
                <div className="card-body">
                  <h5 className="card-title">Open Tickets</h5>
                  <p className="card-text display-4">
                    {devAnalytics?.openTicketsCount}
                  </p>
                </div>
              </div>
            </div>
            <div className="col-6">
              <div className="card text-center">
                <div className="card-body">
                  <h5 className="card-title">Overdue Tickets</h5>
                  <p className="card-text display-4">
                    {devAnalytics?.overdueTicketsCount}
                  </p>
                </div>
              </div>
            </div>
            <div className="col-6">
              <div className="card text-center">
                <div className="card-body">
                  <h5 className="card-title">Active Discussions</h5>
                  <p className="card-text display-4">
                    {devAnalytics?.activeDiscussionsCount}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="card mb-4">
            <div className="card-body">
              <h5 className="card-title">Ticket Status Distribution</h5>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={statusData}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={50}
                    outerRadius={100}
                    fill="#8884d8"
                    paddingAngle={5}
                  >
                    {statusData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={COLORS[index % COLORS.length]}
                      />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import React, { useEffect } from "react";
import Navbar from "../../common/Navbar";
import Sidebar from "../../common/Sidebar";
import { Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthProvider";

export default function Dash() {
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const role = user.role.name.toLowerCase();
    navigate(`/dashboard/${role}`);
  }, [user]);

  return (
    <>
      <Navbar />
      <Sidebar role={user?.role?.name || "User"} />
      <main id="main" className="main">
        <Outlet />
      </main>
    </>
  );
}

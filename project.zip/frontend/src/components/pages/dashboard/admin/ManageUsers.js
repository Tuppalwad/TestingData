import React, { useState, useMemo } from "react";
import DataTable from "react-data-table-component";
import { useAdminData } from "../../../context/AdminDataProvider";
import moment from "moment";
import Swal from "sweetalert2";
import { toast } from "react-toastify";

export default function ManageUsers() {
  const [filterText, setFilterText] = useState("");

  const {
    allUsers,
    updateUserRole,
    updateUserStatus,
    getAllUsers,
    deleteUser,
    setAllUsers,
  } = useAdminData();

  const columns = useMemo(
    () => [
      {
        name: "Name",
        cell: (row) => (
          <p
            data-bs-toggle="tooltip"
            data-bs-placement="top"
            title={`Last login: ${
              row.last_login ? moment(row.last_login).format("LLL") : "Never"
            }`}
          >
            {row.name}
          </p>
        ),
        sortable: true,
      },
      {
        name: "Email",
        selector: (row) => row.email,
        sortable: true,
      },
      {
        name: "Status",
        cell: (row) => (
          <select
            className="form-control form-control-sm"
            value={row.status}
            onChange={(e) => handleStatusChange(row._id, e.target.value)}
          >
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="suspended">Suspended</option>
          </select>
        ),
        sortable: true,
      },
      {
        name: "Role",
        cell: (row) => (
          <select
            className="form-control form-control-sm"
            value={row.role.name}
            onChange={(e) => handleRoleChange(row._id, e.target.value)}
          >
            <option value="Admin">Admin</option>
            <option value="Developer">Developer</option>
            <option value="User">User</option>
          </select>
        ),
        sortable: true,
      },
      {
        name: "Actions",
        cell: (row) => (
          <button
            className="btn btn-sm btn-danger"
            onClick={() => handleDeleteUser(row._id)}
            title="Delete User"
          >
            <i className="bi bi-trash"></i>
          </button>
        ),
      },
    ],
    [allUsers]
  );

  const handleStatusChange = async (userId, newStatus) => {
    const user = allUsers.find((user) => user._id === userId);
    try {
      const confirm = await Swal.fire({
        title: "Are you sure?",
        text: `Change "${user.name}" status to "${newStatus}"?`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, update it!",
        cancelButtonText: "Cancel",
      });

      if (confirm.isConfirmed) {
        await updateUserStatus(userId, newStatus);
        getAllUsers();
      }
    } catch (error) {
      toast.error("Failed to update user status.");
      console.error(error);
    }
  };

  const handleRoleChange = async (userId, newRole) => {
    const user = allUsers.find((user) => user._id === userId);
    const oldRole = user.role.name;

    setAllUsers((prevUsers) =>
      prevUsers.map((u) =>
        u._id === userId ? { ...u, role: { ...u.role, name: newRole } } : u
      )
    );

    try {
      const confirm = await Swal.fire({
        title: "Are you sure?",
        text: `Change "${user.name}" role to "${newRole}"?`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, update it!",
        cancelButtonText: "Cancel",
      });

      if (!confirm.isConfirmed) throw new Error("User canceled the update.");

      await updateUserRole(userId, newRole);
    } catch (error) {
      setAllUsers((prevUsers) =>
        prevUsers.map((u) =>
          u._id === userId ? { ...u, role: { ...u.role, name: oldRole } } : u
        )
      );
      toast.error(error.message);
    }
  };

  const handleDeleteUser = async (userId) => {
    const user = allUsers.find((user) => user._id === userId);
    try {
      const confirm = await Swal.fire({
        title: "Are you sure?",
        text: `Delete user "${user.name}"? This action cannot be undone!`,
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "Cancel",
      });

      if (confirm.isConfirmed) {
        await deleteUser(userId);
        toast.success(`User "${user.name}" has been deleted successfully.`);
        getAllUsers();
      }
    } catch (error) {
      toast.error("Failed to delete the user.");
      console.error(error);
    }
  };

  const filteredItems = useMemo(() => {
    return allUsers.filter(
      (item) =>
        item.name.toLowerCase().includes(filterText.toLowerCase()) ||
        item.email.toLowerCase().includes(filterText.toLowerCase())
    );
  }, [allUsers, filterText]);

  return (
    <>
      <div className="pagetitle">
        <h1>Manage Users</h1>
        <nav>
          <ol className="breadcrumb">
            <li className="breadcrumb-item">
              <a href="/dashboard">Home</a>
            </li>
            <li className="breadcrumb-item active">Manage Users</li>
          </ol>
        </nav>
      </div>

      <section className="section">
        <div className="row">
          <div className="col-lg-12">
            <div className="card">
              <div className="card-body">
                <div className="d-flex justify-content-between align-items-center">
                  <h5 className="card-title">Users Table</h5>
                  <input
                    type="text"
                    placeholder="Search..."
                    className="form-control form-control-sm w-auto"
                    value={filterText}
                    onChange={(e) => setFilterText(e.target.value)}
                  />
                </div>

                <DataTable
                  columns={columns}
                  data={filteredItems}
                  pagination
                  highlightOnHover
                  responsive
                  subHeader
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

import React from "react";

export default function AdminDashboard() {
  return (
    <div>
      <p>AdminDashboard</p>
    </div>
  );
}

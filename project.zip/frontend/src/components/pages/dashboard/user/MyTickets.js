import React, { useState } from "react";
import { useUserData } from "../../../context/UserDataProvider";
import { Link } from "react-router-dom";
import ReactPaginate from "react-paginate";
import "./MyTickets.css"; // Add styles for pagination

export default function MyTickets() {
  const { ticketsForUser } = useUserData();

  // Pagination state
  const [currentPage, setCurrentPage] = useState(0);
  const [ticketsPerPage, setTicketsPerPage] = useState(10); // Default: 10 tickets per page

  // Sort tickets in descending order by creation date
  const sortedTickets = ticketsForUser
    ?.slice()
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  // Pagination logic
  const offset = currentPage * ticketsPerPage;
  const paginatedTickets = sortedTickets?.slice(
    offset,
    offset + ticketsPerPage
  );
  const pageCount = Math.ceil(sortedTickets?.length / ticketsPerPage);

  const handlePageChange = ({ selected }) => {
    setCurrentPage(selected);
  };

  // Helper functions for colors
  const getStateColor = (state) => {
    const stateColors = {
      ACTIVE: "badge-primary",
      "IN PROGRESS": "badge-warning",
      CLOSED: "badge-success",
      REJECTED: "badge-danger",
      RESOLVED: "badge-info",
      REOPENED: "badge-secondary",
    };
    return stateColors[state] || "badge-light";
  };

  const getPriorityColor = (priority) => {
    const priorityColors = {
      Low: "badge-success",
      Medium: "badge-warning",
      High: "badge-danger",
    };
    return priorityColors[priority] || "badge-light";
  };

  return (
    <div>
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Your Tickets</h5>
          <div className="d-flex justify-content-between align-items-center mb-3">
            <label>
              Show{" "}
              <select
                className="form-select form-select-sm d-inline-block w-auto"
                value={ticketsPerPage}
                onChange={(e) => setTicketsPerPage(Number(e.target.value))}
              >
                <option value="5">5</option>
                <option value="10">10</option>
                <option value="20">20</option>
              </select>{" "}
              entries
            </label>
          </div>
          <div className="list-group">
            {paginatedTickets && paginatedTickets.length > 0 ? (
              paginatedTickets.map((ticket) => (
                <Link
                  key={ticket._id}
                  to={`/dashboard/ticket/${ticket.ticketId}`}
                  className="list-group-item list-group-item-action"
                  aria-current="true"
                >
                  <div className="d-flex w-100 justify-content-between">
                    <h5 className="mb-0 fw-bold text-truncate">
                      {ticket.title}
                    </h5>
                    <small className="fw-bold">
                      Due:{" "}
                      {new Date(ticket.due_date).toLocaleDateString("en-US")}
                    </small>
                  </div>
                  <p className="text-muted mb-0 truncate-multiline">
                    <span
                      dangerouslySetInnerHTML={{ __html: ticket.description }}
                    ></span>
                  </p>

                  <small>
                    <span
                      className={`badge ${getStateColor(ticket.state)} me-2`}
                    >
                      {"Ticket : "}
                      {ticket.state}
                    </span>
                    <span
                      className={`badge ${getPriorityColor(
                        ticket.priority
                      )} me-2`}
                    >
                      {"Priority : "}
                      {ticket.priority}
                    </span>
                    Module: {ticket.module} | Submodule: {ticket.submodule}
                  </small>
                </Link>
              ))
            ) : (
              <p className="text-muted">No tickets found.</p>
            )}
          </div>
          <ReactPaginate
            previousLabel={"Previous"}
            nextLabel={"Next"}
            breakLabel={"..."}
            pageCount={pageCount}
            marginPagesDisplayed={2}
            pageRangeDisplayed={3}
            onPageChange={handlePageChange}
            containerClassName={"pagination justify-content-center mt-4"}
            pageClassName={"page-item"}
            pageLinkClassName={"page-link"}
            previousClassName={"page-item"}
            previousLinkClassName={"page-link"}
            nextClassName={"page-item"}
            nextLinkClassName={"page-link"}
            breakClassName={"page-item"}
            breakLinkClassName={"page-link"}
            activeClassName={"active"}
          />
        </div>
      </div>
    </div>
  );
}

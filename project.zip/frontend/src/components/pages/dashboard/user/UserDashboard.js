import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../../../context/AuthProvider";
import { useUserData } from "../../../context/UserDataProvider";
import { useGlobalVariables } from "../../../context/GlobalVariablesProvider";

export default function UserDashboard() {
  const { user } = useAuth();
  const { appName } = useGlobalVariables();
  const { analytics } = useUserData();

  return (
    <div className="card py-3">
      <div className="card-body">
        <h3 className="mb-4">
          Hi <span className="fst-italic fw-bold">{user.name}</span>, Welcome to
          Your Dashboard!
        </h3>
        <p className="text-muted">
          Here's an overview of your activity with <strong>{appName}</strong>.
        </p>
        <hr />

        <div className="row mb-4">
          {[
            {
              title: "Active Tickets",
              count: analytics.activeTicketsCount || 0,
              color: "primary",
            },
            {
              title: "Resolved Tickets",
              count: analytics.resolvedTicketsCount || 0,
              color: "success",
            },
            {
              title: "In Progress",
              count: analytics.pendingReviewsCount || 0,
              color: "warning",
            },
          ].map((item, index) => (
            <div key={index} className="col-md-4">
              <div className={`card text-center border-${item.color}`}>
                <div className="card-body">
                  <h5 className="card-title">{item.title}</h5>
                  <p className={`card-text fs-2 text-${item.color}`}>
                    {item.count}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mb-4">
          <h5>Quick Actions</h5>
          <div className="row">
            <div className="col-md-6 mb-3">
              <Link
                to="/dashboard/create-ticket"
                className="btn btn-primary w-100"
              >
                <i className="bi bi-plus-circle me-2"></i>
                Create New Ticket
              </Link>
            </div>
            <div className="col-md-6 mb-3">
              <Link
                to="/dashboard/user/my-tickets"
                className="btn btn-secondary w-100"
              >
                <i className="bi bi-search me-2"></i>
                View All Tickets
              </Link>
            </div>
          </div>
        </div>

        <div className="mb-4">
          <h5>Recent Activity</h5>
          {analytics.recentActivity && analytics.recentActivity.length > 0 ? (
            <ul className="list-group">
              {analytics.recentActivity.map((activity, index) => (
                <li key={index} className="list-group-item">
                  <i className="bi bi-check-circle-fill text-success me-2"></i>
                  <strong>#{activity.ticketId}:</strong> {activity.title}{" "}
                  <span className="text-muted">({activity.state})</span>
                  <div className="small text-muted">
                    Updated by {activity.created_by.name} on{" "}
                    {new Date(activity.updatedAt).toLocaleString()}
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="text-center text-muted">
              <p>No recent activities to show.</p>
              <Link
                to="/dashboard/create-ticket"
                className="btn btn-outline-primary"
              >
                Create Your First Ticket
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

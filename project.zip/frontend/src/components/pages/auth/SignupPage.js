import React, { useState } from "react";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useAuth } from "../../context/AuthProvider";
import { useNavigate } from "react-router-dom";
import { useGlobalVariables } from "../../context/GlobalVariablesProvider";

export default function SignupPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    termsAccepted: false,
  });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();
  const { allowedDomains, appName } = useGlobalVariables();

  const { signup } = useAuth();

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const validate = () => {
    let isValid = true;
    const newErrors = {};

    // Name validation
    if (!formData.name.trim()) {
      newErrors.name = "Name is required.";
      isValid = false;
    }

    // Email validation
    if (!formData.email.trim()) {
      newErrors.email = "Email is required.";
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Invalid email format.";
      isValid = false;
    } else if (
      allowedDomains !== "*" && // Check domain only if not "*"
      !new RegExp(
        `@(${allowedDomains.replace(/\s+/g, "").split(",").join("|")})$`
      ).test(formData.email)
    ) {
      newErrors.email = `Email domain must be one of: ${allowedDomains}`;
      isValid = false;
    }

    if (!formData.password.trim()) {
      newErrors.password = "Password is required.";
      isValid = false;
    } else if (formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters long.";
      isValid = false;
    }

    if (!formData.termsAccepted) {
      newErrors.termsAccepted = "You must accept the terms and conditions.";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validate()) {
      try {
        await signup(formData.name, formData.email, formData.password);
        setFormData({
          name: "",
          email: "",
          password: "",
          termsAccepted: false,
        });
        navigate("/login");
      } catch (error) {
        toast.error("Signup failed. Please try again.");
      }
    } else {
      toast.error("Please correct the errors in the form.");
    }
  };

  return (
    <div className="container">
      <section className="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-lg-5 col-md-6 d-flex flex-column align-items-center justify-content-center">
              <div className="d-flex justify-content-center py-4">
                <a href="/" className="logo d-flex align-items-center w-auto">
                  <img src="assets/img/logo.png" alt="Logo" />
                  <span className="d-none d-lg-block">{appName}</span>
                </a>
              </div>

              <div className="card mb-3">
                <div className="card-body">
                  <div className="pt-4 pb-2">
                    <h5 className="card-title text-center pb-0 fs-4">
                      Create an Account
                    </h5>
                    <hr />
                  </div>

                  <form
                    className="row g-3 needs-validation"
                    onSubmit={handleSubmit}
                    noValidate
                  >
                    <div className="col-12">
                      <label htmlFor="yourName" className="form-label">
                        Your Name
                      </label>
                      <input
                        type="text"
                        name="name"
                        className={`form-control ${
                          errors.name ? "is-invalid" : ""
                        }`}
                        id="yourName"
                        value={formData.name}
                        onChange={handleChange}
                        required
                      />
                      <div className="invalid-feedback">{errors.name}</div>
                    </div>

                    <div className="col-12">
                      <label htmlFor="yourEmail" className="form-label">
                        Your Email
                      </label>
                      <input
                        type="email"
                        name="email"
                        className={`form-control ${
                          errors.email ? "is-invalid" : ""
                        }`}
                        id="yourEmail"
                        value={formData.email}
                        onChange={handleChange}
                        required
                      />
                      <div className="invalid-feedback">{errors.email}</div>
                    </div>

                    <div className="col-12">
                      <label htmlFor="yourPassword" className="form-label">
                        Password
                      </label>
                      <input
                        type="password"
                        name="password"
                        className={`form-control ${
                          errors.password ? "is-invalid" : ""
                        }`}
                        id="yourPassword"
                        value={formData.password}
                        onChange={handleChange}
                        required
                      />
                      <div className="invalid-feedback">{errors.password}</div>
                    </div>

                    <div className="col-12">
                      <div className="form-check">
                        <input
                          className="form-check-input"
                          name="termsAccepted"
                          type="checkbox"
                          id="acceptTerms"
                          checked={formData.termsAccepted}
                          onChange={handleChange}
                          required
                        />
                        <label
                          className="form-check-label"
                          htmlFor="acceptTerms"
                        >
                          I agree and accept the{" "}
                          <a href="/terms">terms and conditions</a>
                        </label>
                        <div className="invalid-feedback">
                          {errors.termsAccepted}
                        </div>
                      </div>
                    </div>

                    <div className="col-12">
                      <button className="btn btn-primary w-100" type="submit">
                        Create Account
                      </button>
                    </div>

                    <div className="col-12">
                      <p className="small mb-0">
                        Already have an account? <a href="/login">Log in</a>
                      </p>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

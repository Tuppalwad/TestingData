import React from "react";
import { Routes, Route } from "react-router-dom";
import UserDashboard from "../pages/dashboard/user/UserDashboard";
import RoleBasedRoute from "./RoleBasedRoute";
import { UserDataProvider } from "../context/UserDataProvider";
import MyTickets from "../pages/dashboard/user/MyTickets";

const UserAppRoutes = () => {
  return (
    <RoleBasedRoute allowedRoles={["User"]}>
      <UserDataProvider>
        <Routes>
          <Route path="" element={<UserDashboard />} />
          <Route path="my-tickets" element={<MyTickets />} />
        </Routes>
      </UserDataProvider>
    </RoleBasedRoute>
  );
};

export default UserAppRoutes;

import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthProvider";

const RoleBasedRoute = ({ allowedRoles, children }) => {
  const { user, loading } = useAuth();

  if (loading)
    return (
      <div className="loading-overlay">
        <div className="spinner"></div>
        <p>Loading...</p>
      </div>
    );

  if (!user || !allowedRoles.includes(user.role.name)) {
    return <Navigate to="/not-authorized" />;
  }

  return children;
};

export default RoleBasedRoute;

import React from "react";
import { Routes, Route } from "react-router-dom";
import AdminDashboard from "../pages/dashboard/admin/AdminDashboard";
import RoleBasedRoute from "./RoleBasedRoute";
import ManageUsers from "../pages/dashboard/admin/ManageUsers";
import { AdminDataProvider } from "../context/AdminDataProvider";

const AdminAppRoutes = () => {
  return (
    <RoleBasedRoute allowedRoles={["Admin"]}>
      <AdminDataProvider>
        <Routes>
          <Route path="" element={<AdminDashboard />} />
          <Route path="manage-users" element={<ManageUsers />} />
        </Routes>
      </AdminDataProvider>
    </RoleBasedRoute>
  );
};

export default AdminAppRoutes;

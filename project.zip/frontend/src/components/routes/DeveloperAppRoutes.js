import React from "react";
import { Routes, Route } from "react-router-dom";
import DeveloperDashboard from "../pages/dashboard/developer/DeveloperDashboard";

import RoleBasedRoute from "./RoleBasedRoute";
import CreateDoc from "../pages/dashboard/developer/documentation/CreateDoc";
import Documentations from "../pages/dashboard/developer/documentation/Documentations";
import AssignedTickets from "../pages/dashboard/developer/tickets/AssignedTickets";
import Board from "../pages/dashboard/developer/board/Board";
import { DevDataProvider } from "../context/DevDataProvider";

const DeveloperAppRoutes = () => {
  return (
    <RoleBasedRoute allowedRoles={["Developer", "Admin"]}>
      <Routes>
        <Route path="" element={<DeveloperDashboard />} />
        <Route
          path="documentation/create/:ticket_id?"
          element={<CreateDoc />}
        />
        <Route path="documentations" element={<Documentations />} />
        <Route path="tickets/assigned" element={<AssignedTickets />} />
        <Route path="tickets/board" element={<Board />} />
      </Routes>
    </RoleBasedRoute>
  );
};

export default DeveloperAppRoutes;

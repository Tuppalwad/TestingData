import React from "react";

export default function Footer() {
  return (
    <footer
      className="bg-dark text-center text-white py-3"
      style={{
        position: "relative",
        width: "100%",
      }}
    >
      Made with love by Govind Deshmukh
    </footer>
  );
}

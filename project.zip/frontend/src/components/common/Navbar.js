import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthProvider";
import { useGlobalVariables } from "../context/GlobalVariablesProvider";

export default function Navbar() {
  const { appName } = useGlobalVariables();
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const notifications = [
    {
      id: 1,
      icon: "bi-exclamation-circle text-warning",
      title: "Lorem Ipsum",
      description: "Quae dolorem earum veritatis oditseno",
      time: "30 min. ago",
    },
    {
      id: 2,
      icon: "bi-x-circle text-danger",
      title: "Atque rerum nesciunt",
      description: "Quae dolorem earum veritatis oditseno",
      time: "1 hr. ago",
    },
    {
      id: 3,
      icon: "bi-check-circle text-success",
      title: "Sit rerum fuga",
      description: "Quae dolorem earum veritatis oditseno",
      time: "2 hrs. ago",
    },
    {
      id: 4,
      icon: "bi-info-circle text-primary",
      title: "Dicta reprehenderit",
      description: "Quae dolorem earum veritatis oditseno",
      time: "4 hrs. ago",
    },
  ];

  const handleLogout = async () => {
    try {
      await logout();
      navigate("/login");
    } catch (error) {
      console.error("Error during logout:", error);
    }
  };

  return (
    <header id="header" className="header fixed-top d-flex align-items-center">
      <div className="d-flex align-items-center justify-content-between">
        <a href="/dashboard" className="logo d-flex align-items-center">
          <img src="/assets/img/logo.png" alt="Logo" />
          <span className="d-none d-lg-block">{appName}</span>
        </a>
        {/* <i className="bi bi-list toggle-sidebar-btn"></i> */}
      </div>

      <nav className="header-nav ms-auto">
        <ul className="d-flex align-items-center">
          <li className="nav-item d-block d-lg-none">
            <a className="nav-link nav-icon search-bar-toggle " href="#">
              <i className="bi bi-search"></i>
            </a>
          </li>

          {/* Notifications */}
          {/* <li className="nav-item dropdown">
            <a className="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
              <i className="bi bi-bell"></i>
              <span className="badge bg-primary badge-number">
                {notifications.length}
              </span>
            </a>

            <ul className="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
              <li className="dropdown-header">
                You have {notifications.length} new notifications
                <a href="#">
                  <span className="badge rounded-pill bg-primary p-2 ms-2">
                    View all
                  </span>
                </a>
              </li>
              <li>
                <hr className="dropdown-divider" />
              </li>

              {notifications.map((notification) => (
                <React.Fragment key={notification.id}>
                  <li className="notification-item">
                    <i className={notification.icon}></i>
                    <div>
                      <h4>{notification.title}</h4>
                      <p>{notification.description}</p>
                      <p>{notification.time}</p>
                    </div>
                  </li>
                  <li>
                    <hr className="dropdown-divider" />
                  </li>
                </React.Fragment>
              ))}

              <li className="dropdown-footer">
                <a href="#">Show all notifications</a>
              </li>
            </ul>
          </li> */}

          {/* Profile Dropdown */}
          <li className="nav-item dropdown pe-3">
            <a
              className="nav-link nav-profile d-flex align-items-center pe-0"
              href="#"
              data-bs-toggle="dropdown"
            >
              <img
                src={user.profile_picture}
                alt="Profile"
                className="rounded-circle"
              />
              <span className="d-none d-md-block dropdown-toggle ps-2">
                {user.name}
              </span>
            </a>

            <ul className="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
              <li className="dropdown-header">
                <h6>{user.email}</h6>
                <span>{user.role.name}</span>
              </li>
              <li>
                <hr className="dropdown-divider" />
              </li>

              <li>
                <Link
                  className="dropdown-item d-flex align-items-center"
                  to="/dashboard/profile"
                >
                  <i className="bi bi-person"></i>
                  <span>My Profile</span>
                </Link>
              </li>
              <li>
                <hr className="dropdown-divider" />
              </li>

              <li>
                <a
                  className="dropdown-item d-flex align-items-center"
                  onClick={handleLogout}
                >
                  <i className="bi bi-box-arrow-right"></i>
                  <span>Sign Out</span>
                </a>
              </li>
            </ul>
          </li>
        </ul>
      </nav>
    </header>
  );
}

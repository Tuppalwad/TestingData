import React from "react";
import { Link } from "react-router-dom";

const menu = {
  Admin: [
    { label: "Dashboard", icon: "bi bi-grid", path: "/dashboard/admin" },
    {
      label: "Manage Users",
      icon: "bi bi-people",
      path: "/dashboard/admin/manage-users",
    },
    {
      label: "Reports",
      icon: "bi bi-bar-chart",
      path: "/dashboard/admin/reports",
    },
    { label: "Board", icon: "bi bi-list-task", path: "/dashboard/admin/board" },
    {
      label: "Settings",
      icon: "bi bi-gear",
      path: "/dashboard/admin/settings",
    },
    {
      label: "Audit Logs",
      icon: "bi bi-file-earmark-text",
      path: "/dashboard/admin/audit-logs",
    },
  ],
  Developer: [
    { label: "Dashboard", icon: "bi bi-grid", path: "/dashboard/developer" },
    {
      label: "Board",
      icon: "bi bi-list-task",
      path: "/dashboard/developer/tickets/board",
    },
    {
      label: "Assigned Tickets",
      icon: "bi bi-ticket",
      path: "/dashboard/developer/tickets/assigned",
    },
    {
      label: "Create Documentation",
      icon: "bi bi-book",
      path: "/dashboard/developer/documentation/create",
    },
    {
      label: "Documentations",
      icon: "bi bi-code",
      path: "/dashboard/developer/documentations",
    },
  ],
  User: [
    { label: "Dashboard", icon: "bi bi-grid", path: "/dashboard/user" },
    {
      label: "Create Ticket",
      icon: "bi bi-envelope",
      path: "/dashboard/create-ticket",
    },
    {
      label: "My Tickets",
      icon: "bi bi-card-list",
      path: "/dashboard/user/my-tickets",
    },
  ],
};

export default function Sidebar({ role }) {
  // Get the menu items for the current role
  const roleMenu = menu[role] || [];

  return (
    <aside id="sidebar" className="sidebar">
      <ul className="sidebar-nav" id="sidebar-nav">
        {roleMenu.map((item, index) => (
          <li className="nav-item" key={index}>
            <Link to={item.path} className="nav-link">
              <i className={item.icon}></i>
              <span>{item.label}</span>
            </Link>
          </li>
        ))}
      </ul>
    </aside>
  );
}

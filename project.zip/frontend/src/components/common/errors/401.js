import React from "react";

export default function NotAuthorized() {
  return (
    <div class="container">
      <section class="section error-404 min-vh-100 d-flex flex-column align-items-center justify-content-center">
        <h1>401</h1>
        <h2>You are not Authorized to view this page.</h2>
        <a class="btn" href="/dashboard">
          Back to home
        </a>
      </section>
    </div>
  );
}

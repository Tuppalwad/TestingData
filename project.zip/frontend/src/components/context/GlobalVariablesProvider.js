import React, { createContext, useContext } from "react";

const GlobalVariablesContext = createContext();

export const GlobalVariablesProvider = ({ children }) => {
  const globalVariables = {
    apiUrl: process.env.REACT_APP_API_URL || "http://10.25.133.182:5000",
    appName: process.env.REACT_APP_APP_NAME || "Demo",
    allowedDomains: process.env.REACT_APP_ALLOWED_DOMAIN || "*",
  };

  return (
    <GlobalVariablesContext.Provider value={globalVariables}>
      {children}
    </GlobalVariablesContext.Provider>
  );
};

export const useGlobalVariables = () => {
  const context = useContext(GlobalVariablesContext);
  if (context === undefined) {
    throw new Error(
      "useGlobalVariables must be used within a GlobalVariablesProvider"
    );
  }
  return context;
};

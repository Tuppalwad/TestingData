import React, { createContext, useContext, useState, useEffect } from "react";
import { toast } from "react-toastify";
import axios from "axios";
import { useGlobalVariables } from "./GlobalVariablesProvider";
import { useAuth } from "./AuthProvider";
import { useCommonData } from "./CommonDataProvider";

const UserDataContext = createContext();

export const useUserData = () => {
  return useContext(UserDataContext);
};

export const UserDataProvider = ({ children }) => {
  const [ticketsForUser, setTickets] = useState([]);
  const [analytics, setAnalytics] = useState({
    activeTicketsCount: 0,
    resolvedTicketsCount: 0,
    pendingReviewsCount: 0,
    recentActivity: [],
  });

  const { apiUrl } = useGlobalVariables();
  const { user } = useAuth();
  const { socket } = useCommonData();

  const getAuthHeaders = () => {
    const token = localStorage.getItem("token");
    if (!token) {
      toast.error("Authentication token is missing.");
      return {};
    }
    return { Authorization: `Bearer ${token}` };
  };

  useEffect(() => {
    if (!user || !apiUrl) return;

    const fetchData = async () => {
      try {
        if (!user.role || user.role.name === "User") {
          await fetchTicketsForUser();
          await fetchAnalyticsForUser();
        }
      } catch (error) {
        console.error("Error fetching ticket data:", error);
        toast.error("Unable to load ticket data. Please try again.");
      }
    };

    fetchData();
  }, [user, apiUrl]);

  const fetchTicketsForUser = async () => {
    try {
      const response = await axios.get(
        `${apiUrl}/api/tickets/getticketsforuser`,
        {
          headers: getAuthHeaders(),
        }
      );
      setTickets(response.data.tickets || []);
    } catch (error) {
      console.error("Error fetching tickets for user:", error);
      toast.error("Error fetching your tickets. Please try again.");
    }
  };

  const fetchAnalyticsForUser = async () => {
    try {
      const response = await axios.get(`${apiUrl}/api/tickets/analytics`, {
        headers: getAuthHeaders(),
      });
      setAnalytics(
        response.data || {
          activeTicketsCount: 0,
          resolvedTicketsCount: 0,
          pendingReviewsCount: 0,
          recentActivity: [],
        }
      );
    } catch (error) {
      console.error("Error fetching analytics for user:", error);
      toast.error("Error fetching your analytics. Please try again.");
    }
  };

  useEffect(() => {
    if (!socket) return;

    // Ticket Updated Event
    socket.on("ticketUpdated", (updatedTicket) => {
      setTickets((prevTickets) =>
        prevTickets.map((ticket) =>
          ticket._id === updatedTicket._id ? updatedTicket : ticket
        )
      );
    });

    // New Comment Event
    socket.on("newComment", ({ ticket_id, comment }) => {
      setTickets((prevTickets) =>
        prevTickets.map((ticket) =>
          ticket._id === ticket_id
            ? { ...ticket, comments: [...ticket.comments, comment] }
            : ticket
        )
      );
    });

    // New Reply Event
    socket.on("newReply", ({ ticket_id, parentCommentId, reply }) => {
      setTickets((prevTickets) =>
        prevTickets.map((ticket) =>
          ticket._id === ticket_id
            ? {
                ...ticket,
                comments: ticket.comments.map((comment) =>
                  comment._id === parentCommentId
                    ? { ...comment, replies: [...comment.replies, reply] }
                    : comment
                ),
              }
            : ticket
        )
      );
    });

    return () => {
      socket.off("ticketCreated");
      socket.off("ticketUpdated");
      socket.off("newComment");
      socket.off("newReply");
    };
  }, [socket]);

  return (
    <UserDataContext.Provider
      value={{
        ticketsForUser,
        analytics,
      }}
    >
      {children}
    </UserDataContext.Provider>
  );
};

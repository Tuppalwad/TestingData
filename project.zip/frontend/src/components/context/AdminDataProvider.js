import React, { createContext, useContext, useState, useEffect } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { useGlobalVariables } from "./GlobalVariablesProvider";

const AdminDataContext = createContext(null);

export const AdminDataProvider = ({ children }) => {
  const [allUsers, setAllUsers] = useState([]);
  const { apiUrl } = useGlobalVariables();

  const getAuthHeaders = () => {
    const token = localStorage.getItem("token");
    if (!token) {
      toast.error("Authentication token is missing.");
      return {};
    }
    return { Authorization: `Bearer ${token}` };
  };

  const getAllUsers = async () => {
    try {
      const response = await axios.get(`${apiUrl}/api/admin/getallusers`, {
        headers: getAuthHeaders(),
      });
      setAllUsers(response.data.users);
    } catch (error) {
      console.error("Error fetching users:", error);
      const message =
        error.response?.data?.message || "An unexpected error occurred.";
      toast.error(message);
    }
  };

  const updateUserRole = async (userId, userRole) => {
    try {
      const response = await axios.put(
        `${apiUrl}/api/admin/updateuserrole`,
        { userId, userRole },
        { headers: getAuthHeaders() }
      );
      setAllUsers((prevUsers) =>
        prevUsers.map((user) =>
          user._id === userId ? { ...user, ...response.data.updatedUser } : user
        )
      );
      toast.success("User role updated successfully!");
    } catch (error) {
      console.error("Error updating user role:", error);
      const message =
        error.response?.data?.message || "An unexpected error occurred.";
      toast.error(message);
    }
  };

  const updateUserStatus = async (userId, userStatus) => {
    try {
      const response = await axios.put(
        `${apiUrl}/api/admin/updateuserstatus`,
        { userId, status: userStatus },
        { headers: getAuthHeaders() }
      );
      setAllUsers((prevUsers) =>
        prevUsers.map((user) =>
          user._id === userId ? { ...user, ...response.data.updatedUser } : user
        )
      );
      toast.success("User profile status updated successfully!");
    } catch (error) {
      console.error("Error updating user status:", error);
      const message =
        error.response?.data?.message || "An unexpected error occurred.";
      toast.error(message);
    }
  };

  const deleteUser = async (userId) => {
    try {
      await axios.delete(`${apiUrl}/api/admin/deleteuser`, {
        data: { userId },
        headers: getAuthHeaders(),
      });
      setAllUsers((prevUsers) =>
        prevUsers.filter((user) => user._id !== userId)
      );
      toast.success("User deleted successfully!");
    } catch (error) {
      console.error("Error deleting user:", error);
      const message =
        error.response?.data?.message || "An unexpected error occurred.";
      toast.error(message);
    }
  };

  useEffect(() => {
    getAllUsers();
  }, [apiUrl]);

  return (
    <AdminDataContext.Provider
      value={{
        allUsers,
        getAllUsers,
        updateUserRole,
        updateUserStatus,
        deleteUser,
        setAllUsers,
      }}
    >
      {children}
    </AdminDataContext.Provider>
  );
};

export const useAdminData = () => {
  const context = useContext(AdminDataContext);
  if (!context) {
    throw new Error("useAdminData must be used within a AdminDataProvider");
  }
  return context;
};

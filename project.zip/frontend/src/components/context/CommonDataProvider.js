import React, { createContext, useContext, useState, useEffect } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { io } from "socket.io-client";
import { useAuth } from "./AuthProvider";
import { useGlobalVariables } from "./GlobalVariablesProvider";

const CommonDataContext = createContext();

export const CommonDataProvider = ({ children }) => {
  const [comments, setComments] = useState([]);
  const [socket, setSocket] = useState(null);
  const [assignedUsersOptions, setAssignedUsersOptions] = useState([]);
  const { apiUrl } = useGlobalVariables();
  const { user } = useAuth();
  const [myTickets, setMyTickets] = useState([]);
  const [ticket, setTicket] = useState([]);

  useEffect(() => {
    if (!user || !apiUrl) return;

    const socketConnection = io(apiUrl, {
      query: { token: localStorage.getItem("token") },
    });

    setSocket(socketConnection);

    socketConnection.on("connect", () => {
      console.log("Connected to socket:", socketConnection.id);
    });

    socketConnection.on("ticketCreated", (newTicket) => {
      toast.success("A new ticket has been created!");
      setTicket((prevTickets) =>
        Array.isArray(prevTickets) ? [newTicket, ...prevTickets] : [newTicket]
      );
    });

    socketConnection.on("ticketUpdated", (updatedTicket) => {
      toast.info("A ticket has been updated.");
      setTicket((prevTickets) =>
        Array.isArray(prevTickets)
          ? prevTickets.map((ticket) =>
              ticket._id === updatedTicket._id ? updatedTicket : ticket
            )
          : []
      );
    });

    socketConnection.on("newComment", (data) => {
      toast.success("A new comment has been added!");
      setComments((prevComments) => [...prevComments, data.comment]);
    });

    socketConnection.on("newReply", (data) => {
      toast.success("A new reply has been added!");
      setComments((prevComments) =>
        prevComments.map((comment) =>
          comment._id === data.parentCommentId
            ? { ...comment, replies: [...comment.replies, data.reply] }
            : comment
        )
      );
    });

    return () => {
      socketConnection.disconnect();
    };
  }, [user, apiUrl]);

  const getAuthHeaders = () => {
    const token = localStorage.getItem("token");
    if (!token) {
      toast.error("Authentication token is missing.");
      return {};
    }
    return { Authorization: `Bearer ${token}` };
  };

  const CreateTicket = async (ticketData) => {
    try {
      const response = await axios.post(
        `${apiUrl}/api/tickets/create`,
        ticketData,
        {
          headers: getAuthHeaders(),
        }
      );
      toast.success("Ticket created successfully!");
      return response.data;
    } catch (error) {
      toast.error("There was an issue creating the ticket. Please try again.");
      console.error("Ticket creation error:", error);
    }
  };

  const getTicketByTicketId = async (ticketId) => {
    try {
      const response = await axios.get(`${apiUrl}/api/tickets/${ticketId}`, {
        headers: getAuthHeaders(),
      });
      setTicket(response.data);
    } catch (error) {
      toast.error("There was an issue fetching the ticket. Please try again.");
      console.error("Ticket fetching error:", error);
    }
  };

  const getTicketsForUser = async () => {
    try {
      const response = await axios.get(
        `${apiUrl}/api/tickets/getticketsforuser`,
        {
          headers: getAuthHeaders(),
        }
      );
      setMyTickets();
    } catch (err) {
      toast.error("Unable to your tickets. Please try again.");
    }
  };

  const getCommentsForTicket = async (ticketId) => {
    try {
      const response = await axios.get(
        `${apiUrl}/api/tickets/comments/${ticketId}`,
        {
          headers: getAuthHeaders(),
        }
      );
      setComments(response.data || []);
    } catch (err) {
      console.error("Error fetching comments:", err);
      toast.error("Unable to load comments. Please try again.");
    }
  };

  const createComment = async (commentData) => {
    try {
      const response = await axios.post(
        `${apiUrl}/api/tickets/addcomment`,
        commentData,
        {
          headers: getAuthHeaders(),
        }
      );
      toast.success("Comment created successfully.");
      setComments((prevComments) => [...prevComments, response.data]);
    } catch (err) {
      console.error("Error creating comment:", err);
      toast.error("Unable to create comment. Please try again.");
    }
  };

  const updateTicket = async (updatedData) => {
    try {
      const response = await axios.put(
        `${apiUrl}/api/tickets/update`,
        updatedData,
        {
          headers: getAuthHeaders(),
        }
      );
      const updatedTicket = response.data.updatedTicket;
      setTicket(updatedTicket);
      toast.success("Ticket updated successfully.");
    } catch (err) {
      console.error("Error updating ticket:", err);
      toast.error("Failed to update the ticket. Please try again.");
    }
  };

  const getDevsAndAdmins = async () => {
    try {
      const response = await axios.get(`${apiUrl}/api/auth/devs`, {
        headers: getAuthHeaders(),
      });
      setAssignedUsersOptions(response.data);
      return response.data;
    } catch (error) {
      console.error("Error fetching data for user:", error);
      toast.error("Error fetching your data. Please refresh page.");
    }
  };

  return (
    <CommonDataContext.Provider
      value={{
        ticket,
        comments,
        CreateTicket,
        getTicketByTicketId,
        createComment,
        getCommentsForTicket,
        socket,
        assignedUsersOptions,
        getDevsAndAdmins,
        updateTicket,
      }}
    >
      {children}
    </CommonDataContext.Provider>
  );
};

export const useCommonData = () => {
  const context = useContext(CommonDataContext);
  if (context === undefined) {
    throw new Error("useCommonData must be used within a CommonDataProvider");
  }
  return context;
};

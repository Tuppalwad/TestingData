import React, { createContext, useState, useEffect, useContext } from "react";
import axios from "axios";
import { useCommonData } from "./CommonDataProvider";
import { useGlobalVariables } from "./GlobalVariablesProvider";
import { toast } from "react-toastify";
import { useAuth } from "./AuthProvider";

export const DevDataContext = createContext();

export const DevDataProvider = ({ children }) => {
  const [docs, setDocs] = useState([]);
  const [board, setBoard] = useState([]);
  const [assignedTickets, setAssignedTickets] = useState([]);
  const [devAnalytics, setDevAnalytics] = useState([]);
  const { socket } = useCommonData();
  const { apiUrl } = useGlobalVariables();
  const { user } = useAuth();

  const getAuthHeaders = () => {
    const token = localStorage.getItem("token");
    if (!token) {
      toast.error("Authentication token is missing.");
      return {};
    }
    return { Authorization: `Bearer ${token}` };
  };

  const getDocs = async () => {
    try {
      const response = await axios.get(`${apiUrl}/api/docs`, {
        headers: getAuthHeaders(),
      });
      setDocs(response.data);
    } catch (error) {
      console.error("Error fetching documents", error);
    }
  };

  const createDoc = async (docData) => {
    try {
      const response = await axios.post(`${apiUrl}/api/docs`, docData, {
        headers: getAuthHeaders(),
      });
    } catch (error) {
      console.error("Error creating document", error);
    }
  };

  const updateDoc = async (id, updatedData) => {
    try {
      const response = await axios.put(
        `${apiUrl}/api/docs/${id}`,
        updatedData,
        {
          headers: getAuthHeaders(),
        }
      );
      setDocs((prevDocs) =>
        prevDocs.map((doc) => (doc._id === id ? response.data.doc : doc))
      );
    } catch (error) {
      console.error("Error updating document", error);
    }
  };

  const deleteDoc = async (id) => {
    try {
      const response = await axios.delete(`${apiUrl}/api/docs/${id}`, {
        headers: getAuthHeaders(),
      });
      setDocs((prevDocs) => prevDocs.filter((doc) => doc._id !== id));
    } catch (error) {
      console.error("Error deleting document", error);
    }
  };

  const getBoardData = async () => {
    try {
      const response = await axios.get(`${apiUrl}/api/dev/board`, {
        headers: getAuthHeaders(),
      });
      setBoard(response.data);
    } catch (err) {
      toast.error("Unable to fetch board data");
    }
  };

  const getAssignedTickets = async () => {
    try {
      const response = await axios.get(`${apiUrl}/api/dev/assigned`, {
        headers: getAuthHeaders(),
      });
      setAssignedTickets(response.data.assignedTickets);
    } catch (err) {
      toast.error("Unable to fetch assigned tickets");
    }
  };

  const getDeveloperAnalytics = async () => {
    try {
      const response = await axios.get(`${apiUrl}/api/dev/analytics`, {
        headers: getAuthHeaders(),
      });
      setDevAnalytics(response.data);
    } catch (err) {
      toast.error("Unable to fetch developer analytics");
    }
  };

  useEffect(() => {
    if (!socket) return;

    socket.on("ticketCreated", (newTicket) => {
      setBoard((prevTickets) => [...prevTickets, newTicket]);
      getDeveloperAnalytics();
    });

    socket.on("ticketUpdated", (updatedTicket) => {
      setAssignedTickets((prevTickets) => {
        if (!Array.isArray(prevTickets)) {
          console.error("assignedTickets is not an array:", prevTickets);
          return [];
        }
        return prevTickets.map((ticket) =>
          ticket._id === updatedTicket._id ? updatedTicket : ticket
        );
      });
      getDeveloperAnalytics();
    });

    socket.on("newComment", ({ ticket_id, comment }) => {
      setAssignedTickets((prevTickets) =>
        prevTickets.map((ticket) =>
          ticket._id === ticket_id
            ? { ...ticket, comments: [...ticket.comments, comment] }
            : ticket
        )
      );
    });

    socket.on("newReply", ({ ticket_id, parentCommentId, reply }) => {
      setAssignedTickets((prevTickets) =>
        prevTickets.map((ticket) =>
          ticket._id === ticket_id
            ? {
                ...ticket,
                comments: ticket.comments.map((comment) =>
                  comment._id === parentCommentId
                    ? { ...comment, replies: [...comment.replies, reply] }
                    : comment
                ),
              }
            : ticket
        )
      );
    });

    getAssignedTickets();
    getBoardData();

    return () => {
      socket.off("ticketCreated");
      socket.off("ticketUpdated");
      socket.off("newComment");
      socket.off("newReply");
    };
  }, [socket]);

  return (
    <DevDataContext.Provider
      value={{
        docs,
        board,
        assignedTickets,
        devAnalytics,
        getDocs,
        createDoc,
        updateDoc,
        deleteDoc,
        getBoardData,
        getAssignedTickets,
        getDeveloperAnalytics,
      }}
    >
      {children}
    </DevDataContext.Provider>
  );
};

export const useDevData = () => {
  const context = useContext(DevDataContext);
  if (!context) {
    throw new Error("useDevData must be used within a DevDataProvider");
  }
  return context;
};

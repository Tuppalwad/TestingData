import React, { createContext, useState, useEffect, useContext } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { useGlobalVariables } from "./GlobalVariablesProvider";
const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const { apiUrl } = useGlobalVariables();

  const getToken = () => localStorage.getItem("token");

  useEffect(() => {
    const validateToken = async () => {
      const token = getToken();
      if (!token) {
        setLoading(false);
        return;
      }

      try {
        const response = await axios.get(`${apiUrl}/api/auth/validate-token`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setUser(response.data.user);
      } catch (err) {
        logout(true);
      } finally {
        setLoading(false);
      }
    };

    validateToken();
  }, [apiUrl]);

  const login = async (email, password) => {
    try {
      setLoading(true);
      const response = await axios.post(`${apiUrl}/api/auth/login`, {
        email,
        password,
      });
      const { token, user } = response.data;
      localStorage.setItem("token", token);
      localStorage.setItem("user", user);
      setUser(user);
      toast.success("Login successful!");
    } catch (error) {
      toast.error(error.response?.data?.message || "Login failed. Try again.");
    } finally {
      setLoading(false);
    }
  };

  const signup = async (name, email, password) => {
    try {
      const response = await axios.post(`${apiUrl}/api/auth/signup`, {
        name,
        email,
        password,
      });
      toast.success(response.data.message || "Signup successful!");
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || "Signup failed. Try again.";
      toast.error(errorMessage);
    }
  };

  const logout = (showToast = false) => {
    localStorage.clear();
    sessionStorage.clear();
    setUser(null);
    if (showToast) toast.error("Logged out. .");
  };

  const updateProfile = async (profileData) => {
    try {
      setLoading(true);
      const token = getToken();

      if (!token) {
        throw new Error("No token found. Please log in again.");
      }

      const response = await axios.put(
        `${apiUrl}/api/auth/update-profile`,
        profileData,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      const updatedMetaData = response.data.metaData;

      setUser((prevUser) => {
        const updatedUser = {
          ...prevUser,
          metaData: updatedMetaData,
        };
        localStorage.setItem("user", JSON.stringify(updatedUser));
        return updatedUser;
      });

      toast.success("Profile updated successfully!");
    } catch (error) {
      toast.error(
        error.response?.data?.message || "Failed to update profile. Try again."
      );
    } finally {
      setLoading(false);
    }
  };

  const changePassword = async ({ currentPassword, newPassword }) => {
    try {
      setLoading(true);
      const token = getToken();

      if (!token) {
        throw new Error("No token found. Please log in again.");
      }

      // Backend API call for updating password
      const response = await axios.put(
        `${apiUrl}/api/auth/change-password`,
        { currentPassword, newPassword },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      toast.success(response.data.message || "Password updated successfully!");
    } catch (error) {
      const errorMessage =
        error.response?.data?.message ||
        "Failed to update password. Try again.";
      toast.error(errorMessage);
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        signup,
        logout,
        updateProfile,
        changePassword,
        loading,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);

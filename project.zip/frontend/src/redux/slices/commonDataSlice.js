import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";

// Helper function for authentication headers
const getAuthHeaders = () => {
  const token = localStorage.getItem("token");
  if (!token) {
    toast.error("Authentication token is missing.");
    return {};
  }
  return { Authorization: `Bearer ${token}` };
};

// Async actions
export const fetchMyTickets = createAsyncThunk(
  "commonData/fetchMyTickets",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/api/tickets/getticketsforuser`,
        {
          headers: getAuthHeaders(),
        }
      );
      return response.data;
    } catch (err) {
      toast.error("Unable to fetch your tickets. Please try again.");
      return rejectWithValue(err.response.data);
    }
  }
);

export const fetchTicketById = createAsyncThunk(
  "commonData/fetchTicketById",
  async (ticketId, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}/api/tickets/${ticketId}`,
        {
          headers: getAuthHeaders(),
        }
      );
      return response.data;
    } catch (err) {
      toast.error("Unable to fetch ticket details. Please try again.");
      return rejectWithValue(err.response.data);
    }
  }
);

export const updateTicket = createAsyncThunk(
  "commonData/updateTicket",
  async (updatedData, { rejectWithValue }) => {
    try {
      const response = await axios.put(
        `${process.env.REACT_APP_API_URL}/api/tickets/update`,
        updatedData,
        {
          headers: getAuthHeaders(),
        }
      );
      toast.success("Ticket updated successfully.");
      return response.data.updatedTicket;
    } catch (err) {
      toast.error("Failed to update the ticket. Please try again.");
      return rejectWithValue(err.response.data);
    }
  }
);

// Slice definition
const commonDataSlice = createSlice({
  name: "commonData",
  initialState: {
    myTickets: [],
    ticket: null,
    loading: false,
    error: null,
  },
  reducers: {
    // Define synchronous actions if needed
  },
  extraReducers: (builder) => {
    builder
      // Fetch My Tickets
      .addCase(fetchMyTickets.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchMyTickets.fulfilled, (state, action) => {
        state.loading = false;
        state.myTickets = action.payload;
      })
      .addCase(fetchMyTickets.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      // Fetch Ticket by ID
      .addCase(fetchTicketById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTicketById.fulfilled, (state, action) => {
        state.loading = false;
        state.ticket = action.payload;
      })
      .addCase(fetchTicketById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      // Update Ticket
      .addCase(updateTicket.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateTicket.fulfilled, (state, action) => {
        state.loading = false;
        state.ticket = action.payload;
      })
      .addCase(updateTicket.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default commonDataSlice.reducer;

import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  apiUrl: process.env.REACT_APP_API_URL || "http://10.25.133.182:5000",
  appName: process.env.REACT_APP_APP_NAME || "Demo",
  allowedDomains: process.env.REACT_APP_ALLOWED_DOMAIN || "*",
};

const globalVariablesSlice = createSlice({
  name: "globalVariables",
  initialState,
  reducers: {
    updateApiUrl(state, action) {
      state.apiUrl = action.payload;
    },
  },
});

export const { updateApiUrl } = globalVariablesSlice.actions;

export default globalVariablesSlice.reducer;

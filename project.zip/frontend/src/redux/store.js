import { configureStore } from "@reduxjs/toolkit";
import globalVariablesReducer from "./slices/globalVariablesSlice";
import authReducer from "./slices/authSlice";
import commonDataReducer from "./slices/commonDataSlice";
import devDataReducer from "./slices/devDataSlice";
import userDataReducer from "./slices/userDataSlice";
import adminDataReducer from "./slices/adminDataSlice";

const store = configureStore({
  reducer: {
    globalVariables: globalVariablesReducer,
    auth: authReducer,
    commonData: commonDataReducer,
    devData: devDataReducer,
    userData: userDataReducer,
    adminData: adminDataReducer,
  },
});

export default store;

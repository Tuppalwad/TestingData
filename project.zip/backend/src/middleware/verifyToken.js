const jwt = require("jsonwebtoken");
const User = require("../models/User");

const verifyToken = async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    try {
      token = req.headers.authorization.split(" ")[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      const user = await User.findById(decoded.id).populate("role", "name");

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.status === "inactive" || user.status === "suspended") {
        return res.status(403).json({
          message:
            "Your account is inactive or suspended. Please contact support for assistance.",
        });
      }

      req.user = {
        id: user._id,
        role: user.role.name,
      };
      next();
    } catch (error) {
      return res.status(401).json({ message: "Not authorized, token failed" });
    }
  } else {
    return res.status(401).json({ message: "No token provided" });
  }
};

module.exports = verifyToken;

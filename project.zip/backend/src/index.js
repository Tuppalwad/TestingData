const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const morgan = require("morgan");
const helmet = require("helmet");
const path = require("path");
const { createServer } = require("node:http");

dotenv.config();

// Required imports
const connectDB = require("./config/db");
const { errorHandler, notFound } = require("./middleware/errorMiddleware");
const initialize = require("./config/initialize");
const { initSocket } = require("./socket");

// Routes Imports
const authRoutes = require("./routes/authRoutes");
const adminRoutes = require("./routes/adminRoutes");
const ticketRoutes = require("./routes/ticketRoutes");
const docsRoutes = require("./routes/docRoutes");
const devRoutes = require("./routes/devRoutes");

const app = express();
const server = createServer(app);

// Initialize Socket.IO
initSocket(server);

// Connect to MongoDB
connectDB();

// Initialize roles
initialize();

// Middleware
app.use(express.json());
app.use(helmet());
app.use(cors());

// Logging
if (process.env.NODE_ENV !== "production") {
  app.use(morgan("dev"));
}

// Serve static files
app.use(
  "/public",
  express.static(path.join(__dirname, "../public"), {
    setHeaders: (res) => {
      res.set("Cross-Origin-Resource-Policy", "cross-origin");
    },
  })
);

// Test Route
app.get("/", (req, res) => {
  res.send("API is running...");
});

// App routes
app.use("/api/auth", authRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/tickets", ticketRoutes);
app.use("/api/docs", docsRoutes);
app.use("/api/dev", devRoutes);

// Error handling middleware
app.use(notFound);
app.use(errorHandler);

// Start the server
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

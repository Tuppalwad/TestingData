const mongoose = require("mongoose");

const docSchema = new mongoose.Schema(
  {
    docId: {
      type: String,
      unique: true,
      required: true,
    },
    title: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      required: true,
      trim: true,
    },
    associated_ticket: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Ticket",
    },
    ticketId: {
      type: String,
    },
    module: {
      type: String,
      required: true,
      trim: true,
    },
    submodule: {
      type: String,
      trim: true,
    },
    resolution_steps: {
      type: String,
      required: true,
      trim: true,
    },
    created_by: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    tags: [
      {
        type: String,
        trim: true,
      },
    ],
    references: [
      {
        type: String,
        trim: true,
      },
    ],
  },
  { timestamps: true }
);

function generateUniqueDocId() {
  const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let result = "DOC_";
  for (let i = 0; i < 6; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

docSchema.pre("validate", async function (next) {
  if (this.isNew) {
    let uniqueDocId = generateUniqueDocId();
    const Doc = mongoose.model("Doc");

    let isUnique = false;
    while (!isUnique) {
      const existingDoc = await Doc.findOne({ docId: uniqueDocId });
      if (!existingDoc) {
        isUnique = true;
      } else {
        uniqueDocId = generateUniqueDocId();
      }
    }

    this.docId = uniqueDocId;
  }
  next();
});

module.exports = mongoose.model("Doc", docSchema);

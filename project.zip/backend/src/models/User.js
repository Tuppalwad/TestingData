const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jdenticon = require("jdenticon");
const fs = require("fs");
const path = require("path");

const appApiUrl = process.env.APP_API_URL;

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    username: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
    },
    password: {
      type: String,
      required: true,
    },
    profile_picture: {
      type: String,
      default: null,
    },
    status: {
      type: String,
      enum: ["active", "inactive", "suspended"],
      default: "active",
    },
    metaData: {
      type: Object,
      default: {},
    },
    role: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Role",
      required: true,
    },
    last_login: {
      type: Date,
      default: null,
    },
  },
  { timestamps: true }
);

// Middleware to hash password, generate avatar, and set username
userSchema.pre("save", async function (next) {
  if (this.isModified("password")) {
    this.password = await bcrypt.hash(this.password, 10);
  }

  if (!this.username) {
    const [username] = this.email.split("@");
    this.username = username;
  }

  if (!this.profile_picture) {
    try {
      const avatarSize = 200;
      const avatarPath = path.join(__dirname, "../../public/favicon");
      const avatarFilename = `${this.username}.png`;
      const avatarFilePath = path.join(avatarPath, avatarFilename);

      if (!fs.existsSync(avatarPath)) {
        fs.mkdirSync(avatarPath, { recursive: true });
      }
      const avatarPng = jdenticon.toPng(this.email, avatarSize);
      fs.writeFileSync(avatarFilePath, avatarPng);

      this.profile_picture = `${appApiUrl}/public/favicon/${avatarFilename}`;
    } catch (error) {
      return next(error);
    }
  }

  next();
});

// Method to compare passwords
userSchema.methods.comparePassword = async function (inputPassword) {
  return bcrypt.compare(inputPassword, this.password);
};

module.exports = mongoose.model("User", userSchema);

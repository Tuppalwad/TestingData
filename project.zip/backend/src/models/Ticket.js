const mongoose = require("mongoose");
const crypto = require("crypto");

const TICKETID_INITIALS = process.env.TICKETID_INITIALS || "DEMO_";

const ticketSchema = new mongoose.Schema(
  {
    ticketId: {
      type: String,
      unique: true,
      required: true,
    },
    title: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      required: true,
      trim: true,
    },
    state: {
      type: String,
      enum: [
        "ACTIVE",
        "IN PROGRESS",
        "CLOSED",
        "REJECTED",
        "RESOLVED",
        "REOPENED",
      ],
      default: "ACTIVE",
    },
    priority: {
      type: String,
      enum: ["Low", "Medium", "High"],
      default: "Low",
    },
    module: {
      type: String,
      required: true,
      trim: true,
    },
    submodule: {
      type: String,
      trim: true,
    },
    due_date: {
      type: Date,
      required: true,
    },
    created_by: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    assigned_to: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    rca: {
      type: String,
      trim: true,
    },
    resolution_description: {
      type: String,
      trim: true,
    },
    logs: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Log",
      },
    ],
    comments: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Comment",
      },
    ],
  },
  { timestamps: true }
);

ticketSchema.pre("save", async function (next) {
  if (this.isNew || this.isModified("logs")) {
    for (let log of this.logs) {
      if (log.changed_by) {
        const user = await mongoose.model("User").findById(log.changed_by);
        if (user) {
          log.name = user.name;
        }
      }
    }
  }
  next();
});

function generateUniqueTicketId() {
  const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let result = "EDO_";
  for (let i = 0; i < 6; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

ticketSchema.pre("validate", async function (next) {
  if (this.isNew) {
    let uniqueTicketId = generateUniqueTicketId();
    const Ticket = mongoose.model("Ticket");

    let isUnique = false;
    while (!isUnique) {
      const existingTicket = await Ticket.findOne({ ticketId: uniqueTicketId });
      if (!existingTicket) {
        isUnique = true;
      } else {
        uniqueTicketId = generateUniqueTicketId();
      }
    }

    this.ticketId = uniqueTicketId;
  }
  next();
});

module.exports = mongoose.model("Ticket", ticketSchema);

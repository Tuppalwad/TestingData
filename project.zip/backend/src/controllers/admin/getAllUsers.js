const User = require("../../models/User");

const getAllUsers = async (req, res) => {
  try {
    const { role } = req.user;

    if (role !== "Admin") {
      return res.status(403).json({ message: "Access denied. Admins only." });
    }

    const users = await User.find()
      .select("-password -metaData -profile_picture")
      .populate({
        path: "role",
        select: "name",
      });

    res.status(200).json({ users });
  } catch (error) {
    console.error("Error fetching users:", error.message);
    res.status(500).json({ message: "Server error. Please try again later." });
  }
};

module.exports = getAllUsers;

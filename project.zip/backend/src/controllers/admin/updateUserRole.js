const User = require("../../models/User");
const Role = require("../../models/Role");

const updateUserRole = async (req, res) => {
  try {
    const { role } = req.user;
    const { userId, userRole } = req.body;

    if (role !== "Admin") {
      return res.status(403).json({ message: "Access denied. Admins only." });
    }

    const roleExists = await Role.findOne({ name: userRole });
    if (!roleExists) {
      return res.status(400).json({ message: "Invalid role provided." });
    }
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found." });
    }
    user.role = roleExists._id;
    await user.save();

    res.status(200).json({ message: "User role updated successfully." });
  } catch (error) {
    console.error("Error updating user role:", error.message);
    res.status(500).json({ message: "Server error. Please try again later." });
  }
};

module.exports = updateUserRole;

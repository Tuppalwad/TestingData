const User = require("../../models/User");

const updateProfile = async (req, res) => {
  try {
    const { id } = req.user;

    const user = await User.findById(id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const { about, company, country, address, phone, role } = req.body;

    user.metaData = {
      ...user.metaData,
      about: about || user.metaData.about || "Data not set",
      company: company || user.metaData.company || "Not set",
      role: role || user.metaData.role || "Not Set",
      country: country || user.metaData.country || "Not set",
      address: address || user.metaData.address || "Not Set",
      phone: phone || user.metaData.phone || "Not set",
      role: role || user.metaData.role || "Not set",
    };

    await user.save();

    res.status(200).json({
      message: "Profile updated successfully",
      metaData: user.metaData,
    });
  } catch (error) {
    console.error("Error updating profile:", error.message);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = updateProfile;

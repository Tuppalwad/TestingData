const jwt = require("jsonwebtoken");
const User = require("../../models/User");

const validateTokenController = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];

    if (!token) {
      return res
        .status(400)
        .json({ valid: false, message: "Token is required" });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const user = await User.findById(decoded.id).populate("role", "name");

    if (!user) {
      return res.status(404).json({
        valid: false,
        message: "User not found",
      });
    }

    return res.status(200).json({
      valid: true,
      message: "Token is valid",
      user: {
        id: user._id,
        name: user.name,
        username: user.username,
        email: user.email,
        profile_picture: user.profile_picture,
        status: user.status,
        metaData: user.metaData,
        role: user.role,
      },
    });
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      return res
        .status(401)
        .json({ valid: false, message: "Token has expired" });
    }
    return res.status(401).json({ valid: false, message: "Invalid token" });
  }
};

module.exports = validateTokenController;

const User = require("../../models/User");
const Role = require("../../models/Role");

const fetchDevs = async (req, res) => {
  try {
    const { role } = req.user;

    if (!["Admin", "Developer"].includes(role)) {
      return res
        .status(403)
        .json({ message: "Access denied. Admins and Developers only." });
    }

    const roles = await Role.find({
      name: { $in: ["Admin", "Developer"] },
    });

    const roleIds = roles.map((role) => role._id);

    const users = await User.find({
      role: { $in: roleIds },
    }).select("name email");

    return res.status(200).json(users);
  } catch (err) {
    console.error("Error fetching Admins and Developers:", err);
    return res.status(500).json({ message: "Server error. Please try again." });
  }
};

module.exports = fetchDevs;

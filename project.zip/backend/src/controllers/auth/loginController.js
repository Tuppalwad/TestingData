const User = require("../../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email }).populate("role", "name");

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    if (user.status === "suspended") {
      console.warn(`Suspended user attempted login: ${user.email}`);
      return res.status(401).json({
        message:
          "Your account is suspended. Please contact support for assistance.",
      });
    }

    const old_last_login = user.last_login || "Never";
    user.last_login = new Date();
    await user.save();

    const token = jwt.sign(
      { id: user._id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "12h" }
    );

    const userData = {
      id: user._id,
      name: user.name,
      username: user.username,
      email: user.email,
      profile_picture: user.profile_picture,
      status: user.status,
      metaData: user.metaData,
      role: user.role,
      last_login: old_last_login,
    };

    res.status(200).json({
      message: "Login successful",
      token,
      user: userData,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

module.exports = login;

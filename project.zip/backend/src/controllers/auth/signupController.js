const User = require("../../models/User");
const Role = require("../../models/Role");

const signup = async (req, res) => {
  const { name, username, email, password } = req.body;

  try {
    // Extract domain from email
    const emailDomain = email.split("@")[1];

    // Check allowed domains
    const allowedDomains = process.env.ALLOWED_DOMAINS || "*";
    if (allowedDomains !== "*") {
      const domainList = allowedDomains
        .split(",")
        .map((domain) => domain.trim());
      if (!domainList.includes(emailDomain)) {
        return res
          .status(400)
          .json({ message: "Registration is not allowed for this domain." });
      }
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: "Email is already registered" });
    }

    const generatedUsername = username || email.split("@")[0];

    const existingUsername = await User.findOne({
      username: generatedUsername,
    });
    if (existingUsername) {
      return res.status(400).json({ message: "Username is already taken" });
    }

    // Default role will be User
    let roleName = "User";
    const userCount = await User.countDocuments();
    // First user will be Admin
    if (userCount === 0) {
      roleName = "Admin";
    }

    const roleData = await Role.findOne({ name: roleName });
    if (!roleData) {
      return res.status(500).json({ message: `Role "${roleName}" not found` });
    }

    const newUser = new User({
      name,
      username: generatedUsername,
      email,
      password,
      role: roleData._id,
    });

    await newUser.save();

    res.status(201).json({ message: "User registered successfully" });
  } catch (error) {
    console.error("Signup Error:", error.message);
    res.status(500).json({ message: "Server error. Please try again later." });
  }
};

module.exports = signup;

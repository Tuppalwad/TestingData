const Ticket = require("../../models/Ticket");
const { getIO } = require("../../socket");

const fetchTicketsForDevBoard = async (req, res) => {
  try {
    const tickets = await Ticket.find({})
      .populate("created_by", "name email")
      .populate("assigned_to", "name email");

    res.status(200).json(tickets);
  } catch (error) {
    console.error("Error fetching tickets for developer board:", error);
    res
      .status(500)
      .json({ error: "Unable to fetch tickets for the developer board." });
  }
};

const fetchAssignedTickets = async (req, res) => {
  try {
    const { id } = req.user;
    const assignedTickets = await Ticket.find({ assigned_to: id })
      .populate("created_by assigned_to", "name email")
      .populate("logs");
    res.status(200).json({ assignedTickets });
  } catch (error) {
    console.error("Error fetching assigned tickets:", error);
    res.status(500).json({ error: "Unable to fetch assigned tickets." });
  }
};

module.exports = {
  fetchTicketsForDevBoard,
  fetchAssignedTickets,
};

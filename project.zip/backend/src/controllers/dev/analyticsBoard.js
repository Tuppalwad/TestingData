const Ticket = require("../../models/Ticket");
const Comment = require("../../models/Comment");

const getDeveloperAnalytics = async (req, res) => {
  try {
    const developerId = req.user.id;

    const assignedTicketsCount = await Ticket.countDocuments({
      assigned_to: developerId,
    });

    const openTicketsCount = await Ticket.countDocuments({
      status: "Pending",
    });

    const today = new Date();
    const overdueTicketsCount = await Ticket.countDocuments({
      status: { $ne: "Completed" },
      due_date: { $lt: today },
    });

    const assignedTicketIds = (
      await Ticket.find({ assigned_to: developerId }, "_id")
    ).map((ticket) => ticket._id);

    const activeDiscussionsCount = await Comment.aggregate([
      {
        $match: {
          ticket: { $in: assignedTicketIds },
        },
      },
      {
        $group: {
          _id: "$ticket",
        },
      },
    ]).then((results) => results.length);

    res.status(200).json({
      assignedTicketsCount,
      openTicketsCount,
      overdueTicketsCount,
      activeDiscussionsCount,
    });
  } catch (error) {
    console.error("Error fetching developer analytics:", error);
    res.status(500).json({ error: "Failed to fetch analytics data." });
  }
};

module.exports = { getDeveloperAnalytics };

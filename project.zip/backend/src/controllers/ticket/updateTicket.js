const Ticket = require("../../models/Ticket");
const Log = require("../../models/Log");
const { getIO } = require("../../socket");

const updateTicket = async (req, res) => {
  const { ticketId, logDescription, ...updates } = req.body;
  console.log(req.body);

  if (!logDescription) {
    return res.status(400).json({ message: "Log Description is required." });
  }

  const { id } = req.user;

  try {
    const ticket = await Ticket.findOne({ ticketId: ticketId });
    if (!ticket) {
      return res.status(404).json({ message: "Ticket not found." });
    }

    const changes = {};

    Object.keys(updates).forEach((key) => {
      const newValue = updates[key];
      const oldValue = ticket[key];

      if (newValue !== undefined && newValue !== oldValue) {
        changes[key] = {
          oldValue: oldValue ?? "N/A",
          newValue,
        };
        ticket[key] = newValue;
      }
    });

    if (Object.keys(changes).length === 0) {
      return res.status(400).json({ message: "No changes detected." });
    }

    await ticket.save();

    // Create a log entry for the changes made
    const logEntry = new Log({
      action: Object.entries(changes)
        .map(
          ([key, value]) =>
            `${key} changed from '${value.oldValue}' to '${value.newValue}'`
        )
        .join(", "),
      ticketId: ticket.ticketId,
      ticket_id: ticket._id,
      description: logDescription,
      action_by: id,
      changes,
    });

    await logEntry.save();

    ticket.logs.push(logEntry._id);
    await ticket.save();

    const updatedTicket = await Ticket.findOne({ ticketId })
      .populate({ path: "created_by", select: "name" })
      .populate({
        path: "logs",
        populate: { path: "action_by", select: "name" },
      })
      .populate({
        path: "comments",
        populate: { path: "created_by", select: "name" },
      });

    getIO().emit("ticketUpdated", updatedTicket);

    res.status(200).json({
      message: "Ticket updated successfully.",
      updatedTicket,
    });
  } catch (error) {
    console.error("Error updating ticket:", error);
    res.status(500).json({
      message: "An error occurred while updating the ticket.",
    });
  }
};

module.exports = updateTicket;

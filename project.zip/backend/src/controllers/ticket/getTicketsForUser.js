const User = require("../../models/User");
const Ticket = require("../../models/Ticket");

const getTicketsForUser = async (req, res) => {
  const { id } = req.user;
  try {
    const tickets = await Ticket.find({ created_by: id });
    res.status(200).json({ tickets });
  } catch (error) {
    console.error("Error fetching tickets:", error.message);
    res.status(500).json({ message: "Server error. Please try again later." });
  }
};

module.exports = getTicketsForUser;

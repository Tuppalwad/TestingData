const Ticket = require("../../models/Ticket");
const User = require("../../models/User");
const { getIO } = require("../../socket");

async function createTicket(req, res) {
  const {
    title,
    description,
    priority,
    module,
    submodule,
    dueDate,
    created_by,
  } = req.body;

  try {
    const newTicket = new Ticket({
      title,
      description,
      priority,
      module,
      submodule,
      due_date: dueDate,
      created_by,
    });

    await newTicket.save();

    getIO().emit("ticketCreated", newTicket);

    res.status(201).json(newTicket);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Error creating ticket", error });
  }
}

module.exports = createTicket;

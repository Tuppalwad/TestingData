const Ticket = require("../../models/Ticket");

const ticketAnalyticsUser = async (req, res) => {
  try {
    const { id } = req.user;

    const activeTicketsCount = await Ticket.countDocuments({
      created_by: id,
      state: "ACTIVE",
    });
    const resolvedTicketsCount = await Ticket.countDocuments({
      created_by: id,
      state: "RESOLVED",
    });
    const pendingReviewsCount = await Ticket.countDocuments({
      created_by: id,
      state: "IN PROGRESS",
    });

    const recentActivity = await Ticket.find({
      $or: [{ created_by: id }, { assigned_to: id }],
    })
      .sort({ updatedAt: -1 })
      .limit(5)
      .select("ticketId title state updatedAt")
      .populate("assigned_to", "name")
      .populate("created_by", "name");

    res.status(200).json({
      activeTicketsCount,
      resolvedTicketsCount,
      pendingReviewsCount,
      recentActivity,
    });
  } catch (error) {
    console.error("Error fetching dashboard data:", error.message);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = { ticketAnalyticsUser };

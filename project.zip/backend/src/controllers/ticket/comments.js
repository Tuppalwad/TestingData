const Comment = require("../../models/Comment");
const Ticket = require("../../models/Ticket");
const { getIO } = require("../../socket");

const createComment = async (req, res) => {
  try {
    const { content, ticket_id, ticketId, parentCommentId } = req.body;
    const { id } = req.user;

    const newComment = new Comment({
      content,
      created_by: id,
      ticket_id,
      ticketId: ticketId,
      parentCommentId,
    });
    await newComment.save();
    if (parentCommentId) {
      await Comment.findByIdAndUpdate(parentCommentId, {
        $push: { replies: newComment._id },
      });
      getIO().emit("newReply", {
        ticket_id,
        parentCommentId,
        reply: newComment,
      });
    } else {
      getIO().emit("newComment", { ticket_id, comment: newComment });
    }
    return res.status(201).json(newComment);
  } catch (error) {
    console.error("Error creating comment:", error);
    return res.status(500).json({ error: "Failed to create comment." });
  }
};

const getComments = async (req, res) => {
  try {
    const { ticketId } = req.params;

    const comments = await Comment.find({
      ticketId: ticketId,
      parentCommentId: { $exists: false },
    })
      .populate("created_by", "name")
      .populate({
        path: "replies",
        select: "content created_by createdAt",
        populate: {
          path: "created_by",
          select: "name",
        },
      });

    return res.status(200).json(comments);
  } catch (error) {
    console.error("Error fetching comments:", error);
    return res.status(500).json({ error: "Failed to fetch comments." });
  }
};

module.exports = {
  createComment,
  getComments,
};

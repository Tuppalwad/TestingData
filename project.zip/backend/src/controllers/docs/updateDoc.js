const Doc = require("../../models/Doc");
const { getIO } = require("../../socket");

const updateDoc = async (req, res) => {
  try {
    const { role } = req.user;
    if (!["Admin", "Developer"].includes(role)) {
      return res.status(403).json({
        message: "Access denied. Only Admins and Developers are allowed.",
      });
    }

    const { id } = req.params;
    const updates = req.body;

    const updatedDoc = await Doc.findByIdAndUpdate(id, updates, { new: true });
    if (!updatedDoc) {
      return res.status(404).json({ error: "Document not found" });
    }

    getIO().emit("docUpdated", updatedDoc);

    res.status(200).json({
      message: "Document updated successfully",
      doc: updatedDoc,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to update document" });
  }
};

module.exports = updateDoc;

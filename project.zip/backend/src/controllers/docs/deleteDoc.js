const Doc = require("../../models/Doc");
const { getIO } = require("../../socket");

const deleteDoc = async (req, res) => {
  try {
    const { id } = req.params;
    const { role } = req.user;

    if (role !== "Admin") {
      return res.status(403).json({
        message: "Access denied. Only Admins are allowed to delete documents.",
      });
    }

    const deletedDoc = await Doc.findByIdAndDelete(id);
    if (!deletedDoc) {
      return res.status(404).json({ error: "Document not found" });
    }

    getIO().emit("docDeleted", {
      docId: id,
      message: "Document deleted",
    });

    res.status(200).json({
      message: "Document deleted successfully",
      doc: deletedDoc,
    });
  } catch (error) {
    console.error("Error deleting document:", error);
    res.status(500).json({ error: "Failed to delete document" });
  }
};

module.exports = deleteDoc;

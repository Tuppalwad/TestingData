const Doc = require("../../models/Doc");
const { getIO } = require("../../socket");

const createDoc = async (req, res) => {
  try {
    const { role, id: userId } = req.user;

    if (!["Admin", "Developer"].includes(role)) {
      return res.status(403).json({
        message: "Access denied. Only Admins and Developers are allowed.",
      });
    }

    const {
      title,
      description,
      associated_ticket,
      ticketId,
      module,
      submodule,
      resolution_steps,
      tags = [],
      references = [],
    } = req.body;

    if (!title || !resolution_steps || !description) {
      return res.status(400).json({
        message:
          "Missing required fields: title, resolution_steps, or associated_ticket",
      });
    }

    const newDoc = new Doc({
      title,
      ticketId,
      resolution_steps,
      description,
      tags,
      module,
      submodule,
      associated_ticket,
      created_by: userId,
      references,
    });

    const savedDoc = await newDoc.save();

    getIO().emit("docCreated", savedDoc);

    res.status(201).json({
      message: "Document created successfully",
      doc: savedDoc,
    });
  } catch (error) {
    console.error("Error creating document:", error);
    res.status(500).json({ error: "Failed to create document" });
  }
};

module.exports = createDoc;

const Doc = require("../../models/Doc");

// Get a single document by ID
const getDocById = async (req, res) => {
  try {
    const { id } = req.params;
    const { role } = req.user;
    if (!["Admin", "Developer"].includes(role)) {
      return res.status(403).json({
        message: "Access denied. Only Admins and Developers are allowed.",
      });
    }

    const doc = await Doc.findById(id)
      .populate("associated_ticket")
      .populate("created_by");
    if (!doc) {
      return res.status(404).json({ error: "Document not found" });
    }

    res.status(200).json(doc);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to retrieve document" });
  }
};

// Get all documents
const getAllDocs = async (req, res) => {
  try {
    const { role } = req.user;
    if (!["Admin", "Developer"].includes(role)) {
      return res.status(403).json({
        message: "Access denied. Only Admins and Developers are allowed.",
      });
    }
    const docs = await Doc.find()
      .populate("associated_ticket")
      .populate("created_by", "name email");

    if (docs.length === 0) {
      return res.status(404).json({ message: "No documents found" });
    }

    res.status(200).json(docs);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to retrieve documents" });
  }
};

module.exports = { getDocById, getAllDocs };

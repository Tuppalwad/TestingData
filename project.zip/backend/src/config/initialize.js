const Role = require("../models/Role");

const initializeRoles = async () => {
  const roles = ["Admin", "Developer", "User"];

  try {
    for (const roleName of roles) {
      const existingRole = await Role.findOne({ name: roleName });
      if (!existingRole) {
        await Role.create({ name: roleName, description: `${roleName} role` });
        console.log(`Role "${roleName}" created.`);
      } else {
        console.log(`Role "${roleName}" already exists.`);
      }
    }
    console.log("Role initialization completed.");
  } catch (error) {
    console.error("Error initializing roles:", error.message);
  }
};

module.exports = initializeRoles;

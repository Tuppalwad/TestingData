const express = require("express");

const login = require("../controllers/auth/loginController");
const signup = require("../controllers/auth/signupController");
const updateProfile = require("../controllers/auth/updateProfile");
const changePassword = require("../controllers/auth/changePassword");
const validateTokenController = require("../controllers/auth/validateTokenController");
const fetchDevs = require("../controllers/auth/getDevNames");

const verifyToken = require("../middleware/verifyToken");

const router = express.Router();

router.post("/signup", signup);

router.post("/login", login);

router.put("/update-profile", verifyToken, updateProfile);

router.put("/change-password", verifyToken, changePassword);

router.get("/validate-token", validateTokenController);

router.get("/devs", verifyToken, fetchDevs);

module.exports = router;

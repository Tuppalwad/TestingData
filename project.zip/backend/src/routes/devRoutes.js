const express = require("express");
const router = express.Router();

const {
  fetchTicketsForDevBoard,
  fetchAssignedTickets,
} = require("../controllers/dev/returnTicketsForDev");

const verifyToken = require("../middleware/verifyToken");
const { getDeveloperAnalytics } = require("../controllers/dev/analyticsBoard");

router.get("/board", verifyToken, fetchTicketsForDevBoard);
router.get("/assigned", verifyToken, fetchAssignedTickets);
router.get("/analytics", verifyToken, getDeveloperAnalytics);

module.exports = router;

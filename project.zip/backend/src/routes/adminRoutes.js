const express = require("express");

const getAllUsers = require("../controllers/admin/getAllUsers");
const updateUserRole = require("../controllers/admin/updateUserRole");
const updateUserStatus = require("../controllers/admin/updateUserStatus");
const deleteUser = require("../controllers/admin/deleteUser");

const verifyToken = require("../middleware/verifyToken");

const router = express.Router();

router.get("/getallusers", verifyToken, getAllUsers);

router.put("/updateuserrole", verifyToken, updateUserRole);

router.put("/updateuserstatus", verifyToken, updateUserStatus);

router.delete("/deleteuser", verifyToken, deleteUser);

module.exports = router;

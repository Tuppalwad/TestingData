const express = require("express");

const createTicket = require("../controllers/ticket/createTicket");
const getTicketsForUser = require("../controllers/ticket/getTicketsForUser");

const verifyToken = require("../middleware/verifyToken");
const getTicketById = require("../controllers/ticket/getTicketById");
const {
  ticketAnalyticsUser,
} = require("../controllers/ticket/ticketAnalyticsUser");
const {
  getComments,
  createComment,
} = require("../controllers/ticket/comments");
const updateTicket = require("../controllers/ticket/updateTicket");

const router = express.Router();

router.post("/create", verifyToken, createTicket);
router.get("/getticketsforuser", verifyToken, getTicketsForUser);
router.get("/analytics", verifyToken, ticketAnalyticsUser);
router.get("/:ticketId", verifyToken, getTicketById);
router.put("/update", verifyToken, updateTicket);

router.get("/comments/:ticketId", verifyToken, getComments);
router.post("/addcomment", verifyToken, createComment);

module.exports = router;

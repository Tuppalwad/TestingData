const express = require("express");
const router = express.Router();

const createDoc = require("../controllers/docs/createDoc");
const { getDocById, getAllDocs } = require("../controllers/docs/getDoc");
const updateDoc = require("../controllers/docs/updateDoc");
const deleteDoc = require("../controllers/docs/deleteDoc");

const verifyToken = require("../middleware/verifyToken");

router.post("/", verifyToken, createDoc);
router.get("/", verifyToken, getAllDocs);
router.get("/:id", verifyToken, getDocById);
router.put("/:id", verifyToken, updateDoc);
router.delete("/:id", verifyToken, deleteDoc);

module.exports = router;
